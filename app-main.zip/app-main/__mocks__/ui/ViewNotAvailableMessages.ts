import mocker from "mocker-data-generator";

const messages = {
  title: {
    faker: "random.word()"
  },
  description: {
    faker: "random.word()"
  }
};
export const MessagesGenerator = () => {
  return mocker()
    .schema("schemas", messages, 1)
    .build()
    .then(({ schemas }) => {
      const [schema] = schemas;
      return schema;
    });
};
