import mocker from "mocker-data-generator";

const optionsSchema = {
  view: {
    static: true
  },
  descriptionTranslate: {
    faker: "lorem.words"
  },
  sectionTitleTranslate: {
    faker: "lorem.words"
  },
  tooltipTranslate: {
    faker: "lorem.words"
  }
};

const EngagementGeneralSummaryConfigurationSchema = {
  card_1: {
    id: {
      faker: 'random.number({"min": 1, "max": 999})'
    },
    name_code: {
      static: "card_1"
    },
    report_config_element_id: {
      faker: 'random.number({"min": 1, "max": 999})'
    },
    report_type: {
      faker: 'random.number({"min": 1, "max": 8})'
    },
    survey_id: {
      faker: 'random.number({"min": 1, "max": 8})'
    },
    options: {
      hasOne: "options"
    }
  }
};

const EngagementReportConfigurationSchema = {
  generalSummary: {
    hasOne: "generalSummaryConfiguration"
  }
};

export const EngagementReportConfigurationGenerator = () => {
  return mocker()
    .schema("options", optionsSchema, 1)
    .schema(
      "generalSummaryConfiguration",
      EngagementGeneralSummaryConfigurationSchema,
      1
    )
    .schema(
      "engagementReportConfiguration",
      EngagementReportConfigurationSchema,
      1
    )
    .build()
    .then(
      ({ engagementReportConfiguration: [reportConfiguration] }) =>
        reportConfiguration
    );
};
