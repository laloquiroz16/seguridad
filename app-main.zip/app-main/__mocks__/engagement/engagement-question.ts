import mocker from "mocker-data-generator";

export const EngagementQuestionSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "lorem.words"
  },
  included_in_survey: {
    faker: "random.boolean()"
  },
  parent_name: {
    values: ["Engagement", "Innovación", "Satisfacción", "Compromiso"]
  },
  checked: {
    faker: "random.boolean()"
  }
};

export const EngagementQuestionGenerator = (questionCount: number = 1) => {
  return mocker()
    .schema("questions", EngagementQuestionSchema, questionCount)
    .build();
};
