import mocker from "mocker-data-generator";

const optionsSchema = {
  view: {
    static: true
  },
  descriptionTranslate: {
    faker: "lorem.words"
  },
  sectionTitleTranslate: {
    faker: "lorem.words"
  },
  tooltipTranslate: {
    faker: "lorem.words"
  }
};

const cardConfigurationSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name_code: {
    values: ["card_1", "card_2", "card_3", "card_4", "card_5"]
  },
  options: {
    hasOne: "options"
  },
  report_config_element_id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  survey_id: {
    faker: 'random.number({"min": 1, "max": 999})'
  }
};

export const EngagementNewSurveyReportConfigurationsGenerator = (
  cardsCount: number,
  reportType: number
) => {
  return mocker()
    .schema("options", optionsSchema, 20)
    .schema("cardConfigurations", cardConfigurationSchema, cardsCount)
    .build()
    .then(({ cardConfigurations }) => {
      return cardConfigurations.map(configuration => {
        return { ...configuration, report_type: reportType };
      });
    });
};
