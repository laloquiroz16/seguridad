import mocker from "mocker-data-generator";

export const DimensionsManagementDimensionSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  dimensionType: {
    values: ["domain", "dimension", "item"]
  }
};

export const DimensionsManagementDimensionsGenerator = (
  dimensionsCount: number = 1
) => {
  return mocker()
    .schema("dimensions", DimensionsManagementDimensionSchema, dimensionsCount)
    .build();
};
