import mocker from "mocker-data-generator";

export const EngagementItemSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "lorem.words"
  },
  dimension_type: {
    static: "item"
  },
  included_in_survey: {
    faker: "random.boolean()"
  },
  parent_name: {
    values: ["Engagement", "Innovación", "Satisfacción", "Compromiso"]
  },
  checked: {
    faker: "random.boolean()"
  }
};

export const EngagementDimensionSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "lorem.words"
  },
  dimension_type: {
    values: ["dimension", "item"]
  },
  "object.dimension_type=='item',included_in_survey": {
    faker: "random.boolean()"
  },
  "object.dimension_type=='item',parent_name": {
    values: ["Engagement", "Innovación", "Satisfacción", "Compromiso"]
  },
  "object.dimension_type=='item',checked": {
    faker: "random.boolean()"
  },
  "object.dimension_type=='dimension',children": [
    {
      function() {
        return this.faker.random.arrayElement(this.db.item);
      },
      length: 5,
      fixedLength: false
    }
  ]
};

export const EngagementDomainSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "lorem.words"
  },
  dimension_type: {
    static: "domain"
  },
  children: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.dimension);
      },
      length: 5,
      fixedLength: false
    }
  ]
};

export const EngagementDimensionsHierarchyGenerator = () => {
  return mocker()
    .schema("item", EngagementItemSchema, 35)
    .schema("dimension", EngagementDimensionSchema, 35)
    .schema("dimensionsHierarchy", EngagementDomainSchema, 1)
    .build();
};
