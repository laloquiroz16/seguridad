import mocker from "mocker-data-generator";
import { userSchema } from "../common/user";
import { enterpriseSchema } from "../common/enterprise";

export const actionPlanFileSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 99999})'
  },
  ngfName: {
    faker: "system.fileName"
  },
  name: {
    self: "ngfName"
  },
  user_id: {
    hasOne: "user",
    get: "id"
  }
};

export const ActionPlanFileGenerator = (filesCount: number = 1) => {
  return mocker()
    .schema("enterprise", enterpriseSchema, 1)
    .schema("user", userSchema, 1)
    .schema("files", actionPlanFileSchema, filesCount)
    .build();
};
