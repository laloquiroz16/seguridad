import mocker from "mocker-data-generator";
import { actionPlanTaskSchema } from "./action-plan-task";
import { enterpriseSchema } from "../common/enterprise";
import { actionPlanCommentSchema } from "./action-plan-comments";
import { actionPlanFileSchema } from "./action-plan-file";
import { userSchema } from "../common/user";
import { omit } from "lodash-es";

export const actionPlanSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 99999})'
  },
  title: {
    faker: "lorem.words"
  },
  task_list: {
    hasMany: "tasks",
    min: 1,
    max: 3,
    unique: true
  },
  comments: {
    hasMany: "comments",
    min: 1,
    max: 10
  },
  file_list: {
    hasMany: "files",
    min: 2,
    max: 3,
    unique: true
  },
  process_id: {
    faker: 'random.number({"min": 1, "max": 999})'
  }
};

export const newActionPlanSchema = omit(actionPlanSchema, ["id"]);

export const ActionPlanGenerator = (newActionPlan: boolean = false) => {
  const schema = newActionPlan ? newActionPlanSchema : actionPlanSchema;
  return mocker()
    .schema("enterprise", enterpriseSchema, 1)
    .schema("user", userSchema, 1)
    .schema("tasks", actionPlanTaskSchema, 10)
    .schema("comments", actionPlanCommentSchema, 10)
    .schema("files", actionPlanFileSchema, 10)
    .schema("actionPlans", schema, 1)
    .build()
    .then(({ actionPlans }) => {
      const [actionPlan] = actionPlans;
      return actionPlan;
    });
};

export const ActionPlansGenerator = () => {
  return mocker()
    .schema("enterprise", enterpriseSchema, 1)
    .schema("user", userSchema, 1)
    .schema("tasks", actionPlanTaskSchema, 10)
    .schema("comments", actionPlanCommentSchema, 10)
    .schema("files", actionPlanFileSchema, 10)
    .schema("actionPlans", actionPlanSchema, 10)
    .build();
};
