export const actionPlanCommentSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 99999})'
  },
  user_name: {
    faker: "internet.userName()"
  },
  time: {
    faker: "date.past"
  },
  message: {
    faker: "lorem.paragraph"
  },
  user_id: {
    hasOne: "user",
    get: "id"
  }
};
