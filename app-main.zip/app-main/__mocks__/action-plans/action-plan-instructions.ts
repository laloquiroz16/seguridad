import { supportedLanguages } from "@i18n/supported-languages";
import mocker from "mocker-data-generator";

export const actionPlanInstructionsSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 99999})'
  },
  description: {
    function: function() {
      return supportedLanguages.reduce((current, { code }) => {
        return { ...current, [code]: "" };
      }, {});
    }
  },
  active: {
    static: true
  }
};

export const ActionPlanInstructionsGenerator = () => {
  return mocker()
    .schema("actionPlansInstructions", actionPlanInstructionsSchema, 10)
    .build()
    .then(({ actionPlansInstructions }) => {
      return actionPlansInstructions;
    });
};
