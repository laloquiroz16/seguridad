import mocker from "mocker-data-generator";
import { userSchema } from "../common/user";
import { enterpriseSchema } from "../common/enterprise";

export const actionPlanTaskSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 99999})'
  },
  link: {
    faker: "internet.url"
  },
  data: {
    faker: "lorem.words"
  },
  user_id: {
    hasOne: "user",
    get: "id"
  }
};

export const ActionPlanTaskGenerator = () => {
  return mocker()
    .schema("enterprise", enterpriseSchema, 1)
    .schema("user", userSchema, 1)
    .schema("tasks", actionPlanTaskSchema, 1)
    .build()
    .then(({ tasks }) => {
      const [task] = tasks;
      return task;
    });
};
