import mocker from "mocker-data-generator";
import { RandomizerIntegerSchema } from "../../common/randomizer-integer";

export const MultipleAssessmentCompetencesSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "lorem.word"
  },
  description: {
    faker: "lorem.text"
  },
  conducts: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.numbers);
      },
      length: 2,
      fixedLength: false
    }
  ]
};

export const MultipleAssessmentCompetencesListGenerator = () => {
  return mocker()
    .schema("competences", MultipleAssessmentCompetencesSchema, {
      min: 1,
      max: 10
    })
    .schema("numbers", RandomizerIntegerSchema, 2)
    .build();
};

export const MultipleAssessmentCompetenceGenerator = () => {
  return mocker()
    .schema("competences", MultipleAssessmentCompetencesSchema, 1)
    .schema("numbers", RandomizerIntegerSchema, 2)
    .build()
    .then(({ competences }) => {
      const [competence] = competences;
      return competence;
    });
};
