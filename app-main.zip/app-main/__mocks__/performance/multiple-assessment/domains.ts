import mocker from "mocker-data-generator";
import { MultipleAssessmentCompetencesSchema } from "./competences";

const MultipleAssessmentDomainListSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "name.firstName"
  },
  isSelected: {
    faker: "random.boolean"
  },
  isCompleted: {
    faker: "random.boolean"
  },
  competences: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.competences);
      },
      length: 3,
      fixedLength: false
    }
  ]
};

export const MultipleAssessmentDomainListGenerator = () => {
  return mocker()
    .schema("domains", MultipleAssessmentDomainListSchema, { min: 1, max: 10 })
    .schema("competences", MultipleAssessmentCompetencesSchema, 3)
    .build();
};

export const MultipleAssessmentDomainGenerator = () => {
  return mocker()
    .schema("domains", MultipleAssessmentDomainListSchema, 1)
    .build()
    .then(({ domains }) => {
      const [domain] = domains;
      return domain;
    });
};
