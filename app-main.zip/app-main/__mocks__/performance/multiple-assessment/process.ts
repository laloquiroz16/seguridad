import mocker from "mocker-data-generator";

export const ProcessSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  }
};

export const MultipleAssessmentProcessGenerator = () => {
  return mocker()
    .schema("process", ProcessSchema, 1)
    .build()
    .then(({ process: processes }) => {
      const [process] = processes;
      return process;
    });
};
