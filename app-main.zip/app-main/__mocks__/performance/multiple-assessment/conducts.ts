import mocker from "mocker-data-generator";

const MultipleAssessmentConductSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "lorem.word"
  },
  isCompleted: {
    faker: "random.boolean()"
  }
};

export const MultipleAssessmentConductListGenerator = () => {
  return mocker()
    .schema("conducts", MultipleAssessmentConductSchema, { min: 1, max: 10 })
    .build();
};

export const MultipleAssessmentConductGenerator = () => {
  return mocker()
    .schema("conducts", MultipleAssessmentConductSchema, 1)
    .build()
    .then(({ conducts }) => {
      const [conduct] = conducts;
      return conduct;
    });
};
