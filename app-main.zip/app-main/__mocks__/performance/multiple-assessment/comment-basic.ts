import mocker from "mocker-data-generator";

const MultipleAssessmentCommentBasicSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  comment: {
    faker: "lorem.word"
  },
  createdAt: {
    faker: "date.past"
  },
  updatedAt: {
    faker: "date.future"
  }
};

export const MultipleAssessmentCommentListGenerator = () => {
  return mocker()
    .schema("comments", MultipleAssessmentCommentBasicSchema, {
      min: 1,
      max: 10
    })
    .build();
};

export const MultipleAssessmentCommentGenerator = () => {
  return mocker()
    .schema("comments", MultipleAssessmentCommentBasicSchema, 1)
    .build()
    .then(({ comments }) => {
      const [comment] = comments;
      return comment;
    });
};
