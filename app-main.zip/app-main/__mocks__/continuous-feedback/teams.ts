import mocker from "mocker-data-generator";

const TeamSchema = {
  id: {
    faker: "random.number"
  },
  name: {
    faker: "random.word"
  },
  code: {
    faker: "random.uuid"
  }
};

export const TeamGenerator = () => {
  return mocker()
    .schema("teams", TeamSchema, 5)
    .build();
};
