import mocker from "mocker-data-generator";

const userFeedbackSchema = {
  id: {
    incrementalId: 1
  },
  firstname: {
    faker: "name.firstName"
  },
  middlename: {
    faker: "name.firstName"
  },
  lastname: {
    faker: "name.lastName"
  },
  mothername: {
    faker: "name.lastName"
  },
  avatar: {
    faker: "image.avatar"
  },
  position: {
    faker: "name.jobTitle"
  },
  area: {
    faker: "name.jobArea"
  }
};

export const UserFeedbackGenerator = num => {
  return mocker()
    .schema("users", userFeedbackSchema, num)
    .build();
};
