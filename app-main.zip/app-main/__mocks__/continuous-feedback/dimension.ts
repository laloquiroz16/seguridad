export const DimensionSchema = {
  id: {
    incrementalId: 1,
  },
  name: {
    faker: 'lorem.words',
  },
  description: {
    static: null,
  },
};
