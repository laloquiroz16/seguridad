import mocker from 'mocker-data-generator';
import { DimensionSchema } from './dimension';

const questionOptionSchema = {
  label: {
    faker: 'lorem.words',
  },
  order: {
    chance: 'integer({"min":1})',
  },
  id: {
    incrementalId: 1,
  },
};

const questionSchema = {
  id: {
    incrementalId: 1,
  },
  title: {
    faker: 'lorem.words',
  },
  dimension_type: {
    static: 'item',
  },
  evaluation_type: {
    values: ['txt_free', 'star_rating', 'likert'],
  },
  message: {
    function() {
      if (this.object.evaluation_type === 'txt_free') {
        return null;
      }
      return undefined;
    },
  },
  required: {
    faker: 'random.boolean',
  },
  options: {
    hasMany: 'options',
  },
};

export const QuestionGenerator = (
  questionCount: number = 1,
  dimensionCount = 1
) => {
  return mocker()
    .schema('options', questionOptionSchema, 100)
    .schema('questions', questionSchema, questionCount)
    .schema('dimensions', DimensionSchema, dimensionCount)
    .build();
};
