import { supportedLanguages } from "@i18n/supported-languages";
import mocker from "mocker-data-generator";

const surveySchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  enterprise_process_id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  token: {
    chance: "guid"
  },
  page_title: {
    faker: "lorem.words"
  },
  start_date: {
    faker: "date.past"
  },
  end_date: {
    faker: "date.future"
  },
  title_translate: {
    function: function() {
      return supportedLanguages.reduce((current, { code }) => {
        return { ...current, [code]: "" };
      }, {});
    }
  },
  description_translate: {
    function: function() {
      return supportedLanguages.reduce((current, { code }) => {
        return { ...current, [code]: "" };
      }, {});
    }
  }
};

export const SurveyGenerator = ({
  roleInSurvey = "superadmin",
  canAdminProcess: canAdminProcess = true
}: {
  roleInSurvey?: "superadmin" | "admin" | "manager";
  canAdminProcess?: boolean;
} = {}) => {
  return mocker()
    .schema("surveys", surveySchema, 1)
    .build()
    .then(({ surveys }) => {
      const [survey] = surveys;
      return {
        ...survey,
        role_in_survey: roleInSurvey,
        can_admin_process: canAdminProcess
      };
    });
};
