import mocker from "mocker-data-generator";
import { DomainListSchema } from "./domain-list";

export const ProcessSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  averages_hide: {
    faker: "random.boolean()"
  },
  hide_general_results: {
    faker: "random.boolean()"
  },
  hide_competences_results: {
    faker: "random.boolean()"
  },
  hide_objectives_results: {
    faker: "random.boolean()"
  },
  hide_goals_accomplishment: {
    faker: "random.boolean()"
  },
  associated_feedback_id: {
    faker: 'random.number({"min": 1, "max": 9999})'
  },
  domains_list: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.domainList);
      },
      length: 2,
      fixedLength: false
    }
  ]
};

export const ProcessGenerator = ({
  roleInProcess = "superadmin"
}: {
  roleInProcess?: "superadmin" | "admin" | "manager";
} = {}) => {
  return mocker()
    .schema("domainList", DomainListSchema, 2)
    .schema("process", ProcessSchema, 1)
    .build()
    .then(({ process: processes }) => {
      const [process] = processes;
      return { ...process, role_in_process: roleInProcess };
    });
};
