import mocker from "mocker-data-generator";

export const enterpriseSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "company.companyName"
  },
  slug_enterprise_name: {
    faker: "company.companyName"
  }
};

export const EnterpriseGenerator = () => {
  return mocker()
    .schema("enterprises", enterpriseSchema, 1)
    .build()
    .then(({ enterprises }) => {
      const [enterprise] = enterprises;
      return enterprise;
    });
};
