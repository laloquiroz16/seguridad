import mocker from "mocker-data-generator";
import { domainAttributesSchema } from "./domain-attributes";
import { sectionAttributesSchema } from "./section-attributes";

export const configurationSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  section_attributes: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.section);
       },
      length: 1,
      fixedLength: false
    }
  ],
  domains_attributes: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.domains);
      },
      length: 1,
      fixedLength: false
    }
  ]
};

export const ConfigurationGenerator = () => {
  return mocker()

    .schema("section", sectionAttributesSchema, 1)
    .schema("domains", domainAttributesSchema, 1)
    .schema("configurations", configurationSchema, 1)
    .build()
    .then(({ configurations }) => {
      const [configuration] = configurations;
      return configuration;
    });
};
