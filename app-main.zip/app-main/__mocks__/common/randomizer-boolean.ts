import mocker from "mocker-data-generator";

export const RandomizerBooleanSchema = {
  numberInt: {
    faker: "random.boolean()"
  }
};

export const RandomizerBooleanGenerator = () => {
  return mocker()
    .schema("booleanValues", RandomizerBooleanSchema, { min: 2, max: 10 })
    .build()
    .then(({ booleanValues }) => {
      const [value] = booleanValues;
      return value;
    });
};
