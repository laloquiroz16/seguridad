import mocker from "mocker-data-generator";

export const sectionAttributesSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 9999})'
  },
  show_section: {
    faker: "random.boolean()"
  }
};

export const SectionAttributesGenerator = () => {
  return mocker()
    .schema("section", sectionAttributesSchema, 1)
    .build();
};
