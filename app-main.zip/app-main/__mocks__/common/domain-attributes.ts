import mocker from "mocker-data-generator";
import { averageAttributesSchema } from "./average-attributes";

export const domainAttributesSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 9999})'
  },
  show_domain: {
    faker: "random.boolean()"
  },
  domain_id: {
    faker: 'random.number({"min": 1, "max": 9999})'
  },
  name: {
    faker: "random.word()"
  },
  type_domain: {
    faker: "random.word()"
  },
  average_attributes_attributes: [
    {
      function() {
        return this.faker.random.arrayElement(this.db.average);
      },
      length: 1,
      fixedLength: false
    }
  ]
};

export const DomainAttributesGenerator = () => {
  return mocker()
    .schema("average", averageAttributesSchema, 1)
    .schema("domain", domainAttributesSchema, 1)
    .build();
};
