import mocker from 'mocker-data-generator';

export const DomainListSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})',
  },
  averages_hide: {
    faker: 'random.boolean()',
  },
};
export const DomainListGenerator = () => {
  return mocker()
    .schema('process', DomainListSchema, 1)
    .build();
};
