import mocker from "mocker-data-generator";

export const CompetenceSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  }
};

export const CompetencesGenerator = () => {
  return mocker()
    .schema("competences", CompetenceSchema, 20)
    .build();
};
