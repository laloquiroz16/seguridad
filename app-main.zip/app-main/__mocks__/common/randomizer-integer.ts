import mocker from "mocker-data-generator";

export const RandomizerIntegerSchema = {
  numberInt: {
    faker: 'random.number({"min": 1, "max": 10000})'
  }
};

export const RandomizerIntegerGenerator = () => {
  return mocker()
    .schema("numbers", RandomizerIntegerSchema, { min: 2, max: 10 })
    .build();
};

export const RandomizerOneIntGenerator = () => {
  return mocker()
    .schema("numbers", RandomizerIntegerSchema, { max: 1 })
    .build();
};
