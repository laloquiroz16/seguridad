import mocker from "mocker-data-generator";

export const averageAttributesSchema = {
  domain_id: {
    faker: 'random.number({"min": 1, "max": 9999})'
  },
  id: {
    faker: 'random.number({"min": 1, "max": 9999})'
  },
  show_attribute: {
    faker: "random.boolean()"
  },
  show_comment: {
    faker: "random.boolean()"
  },
  show_graphic: {
    faker: "random.boolean()"
  },
  show_label: {
    faker: "random.boolean()"
  },
  show_value: {
    faker: "random.boolean()"
  },
  type_attribute: "random.word()"

};

export const averageAttributesGenerator = () => {
  return mocker()
    .schema("average", averageAttributesSchema, 1)
    .build();
};
