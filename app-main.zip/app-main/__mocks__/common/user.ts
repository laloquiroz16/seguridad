import mocker from "mocker-data-generator";
import { enterpriseSchema } from "./enterprise";

export const userSchema = {
  id: {
    faker: 'random.number({"min": 1000, "max": 100000})'
  },
  token: {
    chance: "guid"
  },
  name: {
    faker: "name.firstName"
  },
  lastname: {
    faker: "name.lastName"
  },
  middle_name: {
    faker: "name.firstName"
  },
  mothers_name: {
    faker: "name.lastName"
  },
  username: {
    faker: "internet.userName"
  },
  enterprise: {
    hasOne: "enterprise"
  },
  lang: {
    values: ["es", "en", "pt", "ft"]
  }
};

export const UserGenerator = (admin: boolean = true) => {
  return mocker()
    .schema("enterprise", enterpriseSchema, 1)
    .schema("user", userSchema, 1)
    .build()
    .then(({ user: users }) => {
      const [user] = users;
      return { ...user, admin };
    });
};

export const UsersGenerator = (usersCount: number = 15) => {
  return mocker()
    .schema("enterprise", enterpriseSchema, 1)
    .schema("users", userSchema, usersCount)
    .build();
};
