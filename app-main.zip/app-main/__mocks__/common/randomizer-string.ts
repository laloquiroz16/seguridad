import mocker from "mocker-data-generator";

export const RandomizerStringSchema = {
  word: {
    faker: "random.word()"
  }
};

export const RandomizerStringGenerator = () => {
  return mocker()
    .schema("Values", RandomizerStringSchema, { max: 1 })
    .build();
};
