import mocker from 'mocker-data-generator';

export const areaSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})',
  },
  name: {
    faker: 'name.jobArea',
  },
};

export const AreaGenerator = () => {
  return mocker()
    .schema('areas', areaSchema, 1)
    .build()
    .then(({ areas }) => {
      const [area] = areas;
      return area;
    });
};

export const AreasGenerator = () => {
  return mocker()
    .schema('areas', areaSchema, 20)
    .build();
};
