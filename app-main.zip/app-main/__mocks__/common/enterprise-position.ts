import mocker from 'mocker-data-generator';

export const EnterprisePositionSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})',
  },
  name: {
    faker: 'name.jobTitle',
  },
};

export const EnterprisePositionGenerator = () => {
  return mocker()
    .schema('enterprisePositions', EnterprisePositionSchema, 10)
    .build();
};
