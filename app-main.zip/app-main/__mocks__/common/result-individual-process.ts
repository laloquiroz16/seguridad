import mocker from "mocker-data-generator";

export const resultIndividualProcessSchema = {
  id: {
    faker: 'random.number({"min": 1, "max": 999})'
  },
  name: {
    faker: "random.word()"
  },
  enable_digital_report: {
    faker: "random.boolean()"
  },
  configuration_id: {
    faker: 'random.number({"min": 1, "max": 999})'
  }
};

export const ResultIndividualProcessGenerator = () => {
  return mocker()
    .schema("resultIndividualProcesses", resultIndividualProcessSchema, 1)
    .build()
    .then(({ resultIndividualProcesses }) => {
      const [resultIndividualProcess] = resultIndividualProcesses;
      return resultIndividualProcess;
    });
};
