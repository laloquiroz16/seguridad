export function ToastyConfiguration(toastyConfigProvider) {
  "ngInject";
  toastyConfigProvider.setConfig({
    sound: false,
    shake: false,
    limit: 1,
    timeout: 30000
  });
}

export function AuthenticationAndLogConfiguration(
  $logProvider,
  environmentProvider
) {
  "ngInject";
  $logProvider.debugEnabled(
    environmentProvider.get_environment() !== "production"
  );
}

export function HttpConfiguration($httpProvider) {
  "ngInject";

  $httpProvider.defaults.headers.post["Content-Type"] =
    "application/json;charset=utf-8";
  delete $httpProvider.defaults.headers.common["X-Requested-With"];
  $httpProvider.defaults.headers.common["Cache-Control"] = "no-cache";
  $httpProvider.defaults.headers.common.Pragma = "no-cache";
  $httpProvider.defaults.headers.common["If-Modified-Since"] = "0";
  $httpProvider.defaults.headers.get = {
    "Cache-Control": "no-cache"
  };
  $httpProvider.interceptors.push(function (
    $q,
    $rootScope,
    storageService,
    global
  ) {
    "ngInject";
    return {
      request: function (config) {
        $httpProvider.defaults.headers.common["AppID"] = global.appID;

        const { url } = config;
        if (url.match(/\/auth\/common\/[sign_in|sign_out]/g)) {
          config.skipAuthorization = true;
        }

        config.headers["AppID"] = global.appID;
        const token = localStorage.getItem("g-recaptcha-token");
        const jwt = storageService.getCrossCookie("jwt");

        if (token) {
          config.headers["g-recaptcha"] = token;
          localStorage.removeItem("g-recaptcha-token");
        }

        if (jwt) {
          config.headers["Authorization"] = `Bearer ${jwt}`;
        }

        if (
          $rootScope.current_user &&
          storageService.getItem("current_user") &&
          storageService.getItem("current_user").identifier !==
            $rootScope.current_user.identifier
        ) {
          location.reload();
          return (config.timeout = $q.defer().promise);
        } else {
          return config;
        }
      }
    };
  });
  $httpProvider.interceptors.push(function ($injector) {
    "ngInject";
    return {
      responseError: function (resp) {
        return $injector.get("$q").reject(resp);
      }
    };
  });
}
