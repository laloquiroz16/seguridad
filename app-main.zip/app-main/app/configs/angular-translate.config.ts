import { supportedLanguages } from "@i18n/supported-languages";

export function browserLanguage(): string {
  const {
    browserLanguage = "es",
    userLanguage = browserLanguage
  } = navigator as any; // IE >= 10
  const { language = userLanguage } = navigator;
  const [languageCode] = language.split("-");
  const supportedCodes = supportedLanguages.map(({ code }) => code);
  if (!supportedCodes.includes(languageCode)) {
    return "en";
  }
  return languageCode;
}
export function NgTranslateConfiguration(
  $translateProvider: angular.translate.ITranslateProvider
) {
  "ngInject";
  $translateProvider.useSanitizeValueStrategy("sceParameters");
  const [preferredLanguage] = browserLanguage().split("-");
  $translateProvider.preferredLanguage(preferredLanguage);
  $translateProvider.useLoader("AsyncTranslateLoaderService");
}
