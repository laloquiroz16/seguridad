import Raven from "raven-js";

export function RoutingConfiguration($stateProvider, $urlRouterProvider) {
  "ngInject";

  $urlRouterProvider.otherwise(function ($injector) {
    let $rootScope = $injector.get("$rootScope");
    let storageService = $injector.get("storageService");
    let $location = $injector.get("$location");

    storageService.removeCrossCookie("action");
    if ($location.$$path && $location.$$path.includes("id_token")) {
      return;
    }
    if (!$rootScope.current_user) {
      if ($location.$$search.action) {
        const action = $location.$$search.action;
        const subdomain = $location.$$host.split(".")[0];

        const actionCookie = {
          action: action,
          company: subdomain
        };

        storageService.setCrossCookie("action", JSON.stringify(actionCookie));
      }

      if (storageService.getItem("current_user")) {
        return "/home";
      }
      return "/login";
    }
    return "/404";
  });

  $urlRouterProvider.when("", "/login");

  function authenticateRoute() {
    "ngInject";
  }

  /* AUTO ROUTES */
  let modules = [
    {
      state: "survey.**",
      url: "/survey",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "survey.module" */ "../modules/survey/survey.module"
        )
          .then(({ SurveyModule }) => $ocLazyLoad.inject(SurveyModule))
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "survey.module"
              }
            });
          });
      }
    },
    {
      state: "login-sso",
      url: "/rankmi/loginsso?enterpriseToken&authKey=",
      component: "ssoComponent"
    },
    {
      state: "falabella-login-sso",
      url: "/sso/:client?t&m",
      component: "ssoCustomComponent",
      resolve: {
        client: $stateParams => {
          "ngInject";
          return $stateParams.client;
        }
      }
    },
    {
      state: "freshdesk",
      url: "/auth/sso/freshdesk?client_id=&state&redirect_uri&registration_id&nonce",
      component: "freshdesk"
    },
    {
      state: "keycloak-sso",
      url: "/sso-keycloak?session_state&code&et",
      component: "ssoKeycloakComponent"
    },
    {
      state: "generic-sso",
      url: "/generic_sso?data",
      component: "ssoGenericComponent"
    },
    {
      state: "performance_report",
      url: "/reports/enterprise/:enterprise_id/process/:process_id/report?v2_report&i&t&e&lang&enterprise_name",
      lazyLoad: $transition$ => {
        return import("../modules/shared/shared.module").then(
          ({ SharedModule }) => {
            const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
            return $ocLazyLoad.inject(SharedModule);
          }
        );
      },
      component: "reportComponent"
    },

    {
      state: "home.**",
      url: "/v2/home",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "new-home.module" */ "../modules/home/v2/home.module"
        ).then(({ HomeModule }) => {
          return $ocLazyLoad.inject(HomeModule);
        });
      }
    },
    {
      state: "collaborators.**",
      url: "/process/access-management",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "access-management.module" */ "../modules/access_management/access-management.module"
        )
          .then(({ AccessManagementModule }) =>
            $ocLazyLoad.inject(AccessManagementModule)
          )
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "accessManagement.module"
              }
            });
          });
      }
    },
    {
      state: "process_creation.**",
      url: "/process/creation",
      resolve: {
        auth: authenticateRoute
      },
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "process-creation.module" */ "../modules/home/process-creation/process-creation.module"
        )
          .then(loadedModule =>
            $ocLazyLoad.load(loadedModule.PROCESS_CREATION_MODULE)
          )
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "processCreation.module"
              }
            });
          });
      }
    },
    {
      state: "login",
      url: "/login?e=&preview_mode&redirect&moduleNewsid&publicationId",
      component: "loginTemplate"
    },
    {
      state: "not_found",
      url: "/404",
      template: require("../modules/base/notFound.html"),
      abstract: false
    },
    {
      state: "performance.**",
      url: "/performance",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "performance.module" */ "../modules/performance/performance.module"
        )
          .then(({ PerformanceModule }) => {
            $ocLazyLoad.inject(PerformanceModule);
          })
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "performance.module"
              }
            });
          });
      }
    },
    /// ENGAGEMENT
    {
      state: "gptw.**",
      url: "/gptw",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "gptw.module" */ "../modules/gptw/gptw.module"
        )
          .then(({ GPTWModule }) => {
            $ocLazyLoad.inject(GPTWModule);
          })
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "gptw.module"
              }
            });
          });
      }
    },
    {
      state: "open_survey.**",
      url: "/open_survey",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/open_survey/openSurvey.module")
          .then(({ OpenSurveyModule }) => $ocLazyLoad.inject(OpenSurveyModule))
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "openSurvey.module"
              }
            });
          });
      }
    },
    {
      state: "engagement.**",
      url: "/engagement",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "engagement.module" */ "../modules/engagement/engagement.module"
        )
          .then(({ EngagementModule }) => $ocLazyLoad.inject(EngagementModule))
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "engagement.module"
              }
            });
          });
      }
    },
    {
      state: "actionplan.**",
      url: "/actionplan",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "action-plan.module" */ "../modules/actionplan/actionPlan.module"
        )
          .then(({ ACTION_PLAN_MODULE }) =>
            $ocLazyLoad.inject(ACTION_PLAN_MODULE)
          )
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "actionPlan.module"
              }
            });
          });
      }
    },
    // Satisfaction
    {
      state: "satisfaction.**",
      url: "/satisfaction",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/satisfaction/satisfaction.module")
          .then(({ SatisfactionModule }) =>
            $ocLazyLoad.inject(SatisfactionModule)
          )
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "satisfaction.module"
              }
            });
          });
      }
    },
    /// ACCOUNT
    {
      state: "account.**",
      url: "/account",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "account.module" */ "../modules/account/account.module.ts"
        )
          .then(loadedModule => $ocLazyLoad.load(loadedModule.ACCOUNT_MODULE))
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "account.module"
              }
            });
          });
      }
    },
    /// ACCOUNT
    {
      state: "new_account",
      url: "/setup_account",
      resolve: {
        auth: authenticateRoute
      },
      template: require("../modules/setup_account/index.html"),
      abstract: true,
      view: "setup_account_content",
      folder: "modules/setup_account/",
      childs: [
        {
          url: "/edit",
          state: "edit_data",
          template: require("../modules/setup_account/index.html")
        }
      ]
    },
    {
      state: "setup",
      url: "/setup",
      template: require("../modules/auth/index.html"),
      abstract: true
    },
    {
      url: "/update_password?user&recovery_token&invitation&e",
      state: "setup.update_pass",
      component: "updatePasswordComponent"
    },
    {
      url: "/password?user&recovery_token&invitation&e",
      state: "setup.password_first_time",
      data: {
        passwordType: "new_user"
      },
      redirectTo: $transition$ => {
        return {
          state: "setup.update_pass",
          params: $transition$.params()
        };
      }
    },
    {
      state: "talent.**",
      url: "/talent",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import(
          /* webpackChunkName: "talent-management.module" */ "../modules/talent_management/talent-management.module.ts"
        )
          .then(({ TalentManagementModule }) => {
            return $ocLazyLoad.inject(TalentManagementModule);
          })
          .catch(ex => {
            Raven.captureException(ex, {
              extra: {
                bundle: "talentManagement.module"
              }
            });
          });
      }
    },
    {
      state: "open_survey_reply.**",
      url: "/open_survey_reply",
      lazyLoad: $transition$ => {
        let $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/open_survey/reply/reply.module").then(
          ({ OpenSurveyReplyModule }) =>
            $ocLazyLoad.inject(OpenSurveyReplyModule)
        );
      }
    },
    {
      state: "mobileAside",
      url: "/mobileAside",
      component: "mobileAside"
    },
    {
      state: "mobile",
      url: "/v2/home/mobile",
      component: "mobile"
    },
    {
      state: "mobileGroupsSidebar",
      url: "/v2/home/mobileGroupsSidebar",
      component: "mobileGroupsSidebar"
    },
    {
      state: "publicViewDocument",
      url: "/documents/:token/public/:tenant",
      component: "homeDocumentViewWrapper",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/home/v2/signature/signature.module").then(
          ({ HomeSignatureModule }) => {
            return $ocLazyLoad.inject(HomeSignatureModule);
          }
        );
      },
      resolve: {
        token: $transition$ => {
          "ngInject";
          return $transition$.params().token;
        },
        tenant: $transition$ => {
          "ngInject";
          return $transition$.params().tenant;
        },
        publicDocument: () => true
      }
    },
    {
      state: "meetingsSignIn",
      url: "/meetings/signin?code&state",
      component: "meetingsAppLogin",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/meetings/meetings.module").then(
          ({ MeetingsPublicAppModule }) => {
            return $ocLazyLoad.inject(MeetingsPublicAppModule);
          }
        );
      },
      resolve: {
        code: $transition$ => {
          "ngInject";
          return $transition$.params().code;
        },
        state: $transition$ => {
          "ngInject";
          return $transition$.params().state;
        },
        mode: () => "signin"
      }
    },
    {
      state: "meetingsSignUp",
      url: "/meetings/signup?code&error&state",
      component: "meetingsAppLogin",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/meetings/meetings.module").then(
          ({ MeetingsPublicAppModule }) => {
            return $ocLazyLoad.inject(MeetingsPublicAppModule);
          }
        );
      },
      resolve: {
        code: $transition$ => {
          "ngInject";
          return $transition$.params().code;
        },
        state: $transition$ => {
          "ngInject";
          return $transition$.params().state;
        },
        mode: () => "signup"
      }
    },
    {
      state: "meetingsHome",
      url: "/meetings/home",
      component: "meetingsAppHome",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/meetings/meetings.module").then(
          ({ MeetingsPublicAppModule }) => {
            return $ocLazyLoad.inject(MeetingsPublicAppModule);
          }
        );
      }
    },
    {
      state: "meetingsDetails",
      url: "/meetings/:mityId/event/:eventId",
      component: "meetingsAppDetails",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/meetings/meetings-details.module").then(
          ({ MeetingsPublicAppDetailsModule }) => {
            return $ocLazyLoad.inject(MeetingsPublicAppDetailsModule);
          }
        );
      },
      resolve: {
        mityId: $transition$ => {
          "ngInject";
          return $transition$.params().mityId;
        },
        eventId: $transition$ => {
          "ngInject";
          return $transition$.params().eventId;
        }
      }
    },
    {
      state: "meetingsDetailsSingle",
      url: "/meetings/:mityId",
      component: "meetingsAppDetails",
      lazyLoad: $transition$ => {
        const $ocLazyLoad = $transition$.injector().get("$ocLazyLoad");
        return import("../modules/meetings/meetings-details.module").then(
          ({ MeetingsPublicAppDetailsModule }) => {
            return $ocLazyLoad.inject(MeetingsPublicAppDetailsModule);
          }
        );
      },
      resolve: {
        mityId: $transition$ => {
          "ngInject";
          return $transition$.params().mityId;
        },
        eventId: $transition$ => {
          "ngInject";
          return "";
        }
      }
    }
  ];

  modules.forEach(
    ({
      url,
      abstract,
      template,
      resolve,
      lazyLoad,
      component,
      redirectTo,
      state,
      childs = [],
      view
    }) => {
      let routeData = {
        url,
        abstract,
        template,
        resolve,
        lazyLoad,
        component,
        redirectTo
      };

      $stateProvider.state(state, routeData);

      childs.forEach(
        ({
          url,
          parent,
          template,
          state: childState,
          view: childView,
          childs: grandChilds = []
        }) => {
          let childRouteData = {
            url,
            cache: false,
            views: {}
          };

          if (parent) {
            childRouteData.parent = parent;
          }

          childRouteData.views[view] = {
            template
          };

          $stateProvider.state(`${state}.${childState}`, childRouteData);

          grandChilds.forEach(({ url, template, state: granChildState }) => {
            let grandChildRouteData = {
              url,
              views: {}
            };

            grandChildRouteData.views[childView] = {
              template
            };

            $stateProvider.state(
              `${state}.${childState}.${granChildState}`,
              grandChildRouteData
            );
          });
        }
      );
    }
  );
}
