export default function($compileProvider) {
  "ngInject";
  $compileProvider.debugInfoEnabled(process.env.ENV !== "production");
  $compileProvider.commentDirectivesEnabled(false);
  $compileProvider.cssClassDirectivesEnabled(false);
}
