import Raven from "raven-js";
import { IRootScopeService, IWindowService } from "angular";
import { StorageService, GlobalService } from "@base/services";
import { IModalStackService } from "angular-ui-bootstrap";

export function AppBootstrapRunFn(
  $rootScope: IRootScopeService & { [key: string]: any },
  storageService: StorageService,
  global: GlobalService,
  amMoment,
  $window: IWindowService,
  $uibModalStack: IModalStackService
) {
  "ngInject";

  amMoment.changeLocale(global.locale);

  $rootScope.$on("rankmi:updateuser", () => {
    storageService.setItem("current_user", $rootScope.current_user);
  });

  $rootScope.$on("rankmi:dropuser", () => {
    storageService.removeItem("current_user");
    $rootScope.current_user = null;
  });

  $rootScope.$on("rankmi:close_tab", () => {
    $window.close();
  });

  $rootScope.$on("$locationChangeStart", event => {
    const top = $uibModalStack.getTop();
    if (top) {
      $uibModalStack.dismiss(top.key);
      event.preventDefault();
    }
  });

  $window.addEventListener("rankmi::sessionLogout", () => {
    $rootScope.current_user = null;
  });

  Raven.config(
    "https://ab897f196597422e9caa3bc8ccef74f5@o67169.ingest.sentry.io/6661116",
    {
      shouldSendCallback: () => process.env.SENTRY === "True",
      serverName: "rankmi-app",
      ignoreErrors: [
        "Non-Error exception captured with keys: data, status, success"
      ]
    }
  ).install();
}
