export interface IAngularFirabaseApp {
  app: any;
}

export interface IAngularFireArray {
  [key: string]: any;
}
