import { Expose } from "class-transformer";

export class CustomReport {
  @Expose({ name: "id" })
  uuid: string;
  name: string;
  description: string;
  @Expose({ name: "tableau_code" })
  tableauCode: string;
}
