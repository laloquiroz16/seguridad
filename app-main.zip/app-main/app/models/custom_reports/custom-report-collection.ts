import { Expose, Type } from "class-transformer";
import { CustomReport } from "./custom-report";

export class CustomReportCollection {
  @Expose({ name: "tableau_reports" })
  @Type(() => CustomReport)
  reports: CustomReport[];
  total: number;
}
