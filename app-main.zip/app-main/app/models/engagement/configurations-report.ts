export interface IConfigurationsReport {
  /**
   * @description
   */
  mainConfigurations: any;

  /**
   * @description
   */
  generalSummary: any;

  /**
   * @description
   */
  itemsTable: any;

  /**
   * @description
   */
  openQuestios: any;

  /**
   * @description
   */
  resultsTable: any;

  /**
   * @description
   */
  areasTable: any;
}
