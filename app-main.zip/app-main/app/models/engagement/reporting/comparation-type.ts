export enum ComparationType {
  Delta = "delta",
  Score = "score"
}
