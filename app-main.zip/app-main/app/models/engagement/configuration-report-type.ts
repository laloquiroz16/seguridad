export enum ConfigurationReportType {
  Summary = 3,
  General = 4,
  ItemsTable = 5,
  OpenQuestions = 6,
  ResultsTable = 7,
  AreasTable = 8
}
