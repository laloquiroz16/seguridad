export interface ICardConfigurationOptions {
  /**
   * @description
   */
  title: string;

  /**
   * @description
   */
  tooltip: string;

  /**
   * @description
   */
  view: boolean;
}
