export interface ISurveyDomain {
  /**
   * @description Survey key indicator identifier.
   */
  id: number;

  /**
   * @description Scales from positive distribution
   */
  positive_distribution_scale: any[];

  /**
   * @description Name of the key indicator
   */
  name: string;

  /**
   * @description Evaluation type of the key indicator
   */
  evaluation_type: any;
}
