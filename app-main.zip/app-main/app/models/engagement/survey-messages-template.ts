export enum SurveyMessageTemplate {
  Welcome = 1,
  Gratitude = 2
}
