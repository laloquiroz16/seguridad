export interface ITopItemsAnalisysUnits {
  title: string;
  subtitle: string;
  icon: string;
  tabId: string;
  numItems: number;
  visible: () => any;
}
