export enum SurveyInvitationStatus {
  ForInviting = 0,
  Invited = 1
}
