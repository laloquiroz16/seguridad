export enum EngagementMonitoringTabs {
  Areas = "areas",
  People = "people"
}
