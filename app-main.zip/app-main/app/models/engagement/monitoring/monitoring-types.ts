export enum MonitoringTypes {
  Requests = "requests"
}
