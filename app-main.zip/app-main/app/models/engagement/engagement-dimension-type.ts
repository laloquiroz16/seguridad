export enum EngagementDimensionType {
  Domain = "domain",
  Dimension = "dimension",
  Item = "item"
}
