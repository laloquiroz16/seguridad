export interface IGetCollaboratorsParams {
  processId?: number;
  surveyId?: number;
  areaId?: number;
  filters?: any[];
  format?: string;
  withQuestions?: boolean;
  searchTerm?: string;
  page?: number;
  perPage?: number;
}
