export enum DynamicOptionals {
  Gender = "genero"
}
