export enum CreateAssignUserAction {
  CreateUser = "create_user",
  CreateAndAssignUser = "assign_to_survey"
}
