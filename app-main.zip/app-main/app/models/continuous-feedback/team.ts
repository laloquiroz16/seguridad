import { ICollaborator } from "@models/continuous-feedback/collaborator";

export interface ITeam {
  /**
   * @description Team identifier
   */
  id: number;
  /**
   * @description Team name
   */
  name: string;
  /**
   * @description Team collaborators
   */
  collaborators: ICollaborator[];
}
