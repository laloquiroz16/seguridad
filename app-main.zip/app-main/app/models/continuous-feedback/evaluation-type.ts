export enum EvaluationType {
  StarRating = "star_rating",
  TxtFree = "txt_free"
}
