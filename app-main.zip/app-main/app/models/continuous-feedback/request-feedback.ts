export interface IRequestFeedback {
  processToken: string;
  receiver: number;
  content: string;
}
