export interface ICollaborator {
  id: number;
  token: string;
  email: string;
  identifier: string;
  position: string;
  name: string;
  lastname: string;
  complete_name: string;
  user_avatar: string;
  active?: boolean;
}
