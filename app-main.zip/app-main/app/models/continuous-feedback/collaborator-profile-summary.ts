export interface ICollaboratorProfileSummary {
  actions: boolean;
  personalData: boolean;
  feedbackProgress: boolean;
  actionPlansProgress: boolean;
  results: boolean;
}
