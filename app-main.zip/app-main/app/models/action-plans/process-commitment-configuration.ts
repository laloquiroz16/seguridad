import { Expose, Type } from "class-transformer";
import { CommitmentPermissions } from "@models/action-plans/commitment-permissions";

class ProcessCommitmentConfiguration {
  id: number;

  @Expose({ name: "commitment_enabled" })
  commitmentEnabled: boolean;

  @Expose({ name: "commitment_reminders" })
  commitmentReminders: boolean;

  @Expose({ name: "responsable_change_status_enabled" })
  responsableChangeStatusEnabled: boolean;

  @Expose({ name: "commitment_template_enabled" })
  commitmentTemplateEnabled: boolean;

  @Expose({ name: "commitments_in_upper_module_enabled" })
  commitmentInUpperModulerEnabled: boolean;

  @Expose({ name: "allow_auto_commitments" })
  allowAutoCommitment: boolean;

  @Expose({ name: "free_commitment_enable" })
  freeCommitmentEnable: boolean;

  @Expose({ name: "talent_workflow" })
  talentWorkflow: boolean;

  @Expose({ name: "remove_task_only_admin" })
  removeTaskOnlyAdmin: boolean;

  @Expose({ name: "commitment_autoevaluation_enabled" })
  commitmentAutoevaluationEnabled: boolean;

  @Expose({ name: "min_commitments_autoevaluation" })
  minCommitmentsAutoevaluation: number;

  @Expose({ name: "commitment_desc_evaluation_enabled" })
  commitmentDescEvaluationEnabled: boolean;

  @Expose({ name: "min_commitments_desc_evaluation" })
  minCommitmentDescEvaluationEnabled: number;

  @Expose({ name: "automatic_state" })
  automaticState: boolean;

  @Expose({ name: "notify_evaluator_autocommitment_enabled" })
  notifyEvaluatorAutocommitmentEnabled: boolean;

  @Type(() => CommitmentPermissions)
  @Expose({ name: "commitment_permissions" })
  commitmentPermissions: CommitmentPermissions;
}

export { ProcessCommitmentConfiguration };
