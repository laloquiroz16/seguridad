export enum ActionPlanFilters {
  State = "state",
  TotalityState = "totality_state"
}
