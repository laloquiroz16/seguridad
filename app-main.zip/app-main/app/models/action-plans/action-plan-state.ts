export enum ActionPlanState {
  UnStarted = 0,
  InProcess = 1,
  Finished = 2
}
