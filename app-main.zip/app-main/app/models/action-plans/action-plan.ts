export interface IActionPlan {
  /**
   * @description Action plan identifier.
   */
  id: number;

  /**
   * @description Action plan module type
   * @example performance - engagement - satisfaction - talent - gptw
   */
  commitment_type: string;

  /**
   * @description Action plan process identifier
   */
  process_id: number;

  /**
   * @description Action plan survey identifier
   */
  survey_id: number;

  /**
   * @description Action plan link
   */
  link: string;

  /**
   * @description List of tasks associated with the action plan
   */
  task_list: any[];

  /**
   * @description State of action plan
   */
  state: number;

  /**
   * @description Action plan attachmenets
   */
  file_list: any[];
}
