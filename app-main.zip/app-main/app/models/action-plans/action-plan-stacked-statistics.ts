export interface IStackedStatistics {
  titleTotals: string;
  title: string;
  total: any;
  stackedProgress: Array<{
    value: number;
    type: string;
    label: string;
    color: string;
    rawValue: any;
  }>;
}
