import { Expose } from "class-transformer";

class CommitmentPermissions {
  @Expose({ name: "nav_bar_enabled" })
  navBarEnabled: boolean;
  @Expose({ name: "master_access" })
  masterAccess: boolean;
  areasAccess: {} = {};
}

export { CommitmentPermissions };
