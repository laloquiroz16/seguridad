export enum ActionPlanConfigurationControls {
  CurrentPosition = "current_position",
  SuccessorRole = "successor_role"
}
