export enum PeriodTypes {
  Internal = "internal",
  Benchmark = "benchmark"
}
