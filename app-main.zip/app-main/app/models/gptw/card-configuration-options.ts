export interface ICardConfigurationOptions {
  /**
   * @description
   */
  title: string;

  /**
   * @description
   */
  tooltip: string;

  /**
   * @description
   */
  view: boolean;

  /**
   * @description
   */
  view_global_vision: boolean;

  /**
   * @description
   */
  view_area_vision: boolean;

  /**
   * @description
   */
  view_enterprise_vision: boolean;

  /**
   * @description
   */
  view_enterprise_area_comparation: boolean;

  /**
   * @description
   */
  top_items: number;

  /**
   * @description
   */
  view_strengs: boolean;

  /**
   * @description
   */
  view_weaks: boolean;

  /**
   * @description
   */
  view_all_items: boolean;

  /**
   * @description Show Evolution Card Chart as lines
   */
  show_lineal_chart: boolean;

  /**
   * @description Show Evolution Card Chart as bars
   */
  show_bar_chart: boolean;

  /**
   * @description Whether use scale 0 to 100
   */
  show_full_scale: boolean;
}
