export enum GptwReportTypes {
  Area = 1,
  Global = 2
}
