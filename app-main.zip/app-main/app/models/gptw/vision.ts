export interface IVision {
  /**
   * @description Vision identifier
   */
  id: number;
}
