export enum CardNameCodes {
  CardStrengthsOpportunities = "card_5"
}
