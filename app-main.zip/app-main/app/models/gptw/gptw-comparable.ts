export interface IGptwComparable {
  /**
   * @description Identifier of the comparator
   */
  id?: number;

  /**
   * @description Label of the comparator
   */
  label?: string;

  /**
   * @description Default comparable period
   */
  comparable_period_default?: any;

  /**
   * @description Represents the comparable period
   */
  comparable_period?: string;

  /**
   * @description Identifier of the comparable area
   */
  comparable_area_id?: number;

  /**
   * @description Whether the period is active
   */
  active?: boolean;
}
