import { ICardConfigurationOptions } from "@models/gptw/card-configuration-options";

export interface ICardConfiguration {
  /**
   * @description
   */
  id: number;

  /**
   * @description
   */
  name_code: string;

  /**
   * @description
   */
  options: ICardConfigurationOptions;

  /**
   * @description
   */
  report_config_element_id: number;

  /**
   * @description
   */
  report_type: number;

  /**
   * @description
   */
  survey_id: number;
}
