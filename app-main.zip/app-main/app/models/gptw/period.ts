export interface IPeriod {
  /**
   * @description Year of the period
   */
  year: string;

  /**
   * @description Options of the period
   */
  options?: any;

  /**
   * @description Whether the period is active
   */
  active?: boolean;
}
