import { ISurvey } from "@models/common";

export interface IGptw extends ISurvey {
  /**
   * @description Visiones of the survey
   */
  visions: any[];

  /**
   * @description Periods of the survey
   */
  process_periods: any[];

  /**
   * @description Whether areas comparison is enabled
   */
  enabled_area_comparation: boolean;
}
