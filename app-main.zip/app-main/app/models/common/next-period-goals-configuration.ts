export interface INextPeriodGoalsConfiguration {
  id: number;
  enable_objective_goal: boolean;
  visible_goal_comment: boolean;
  hide_objectives: boolean;
  minimum_goals: number;
}
