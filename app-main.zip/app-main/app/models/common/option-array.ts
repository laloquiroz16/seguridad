enum optionArray {
  Add = "add",
  Init = "init",
  Save = "save",
  Remove = "remove"
}
export default optionArray;
