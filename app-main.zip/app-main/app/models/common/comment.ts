import { Expose } from "class-transformer";

export class CommentBasic {
  id?: number;
  comment: string = "";

  @Expose({ name: "created_at" })
  createdAt?: string = "";

  @Expose({ name: "updated_at" })
  updatedAt?: string = "";
}
