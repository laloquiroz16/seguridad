import { ModuleCode } from "@models/common/module-code";

export interface IModule {
  /**
   * @description Module identifier
   */
  id: number;

  /**
   * @description The name of the module
   */
  name: string;

  /**
   * @description Code of module
   */
  code: ModuleCode;
}
