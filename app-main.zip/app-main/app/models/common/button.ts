import { Expose } from "class-transformer";

export class Button {
  @Expose({ name: "is_visible" })
  isVisible: boolean;

  @Expose({ name: "is_enabled" })
  isEnabled?: boolean;
}
