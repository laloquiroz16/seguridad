export enum Languages {
  Es = "es",
  En = "en",
  Fr = "fr",
  Pt = "pt",
  De = "de",
  Pl = "pl"
}
