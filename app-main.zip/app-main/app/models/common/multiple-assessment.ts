export interface IMultipleAssessment {
  /**
   * @description is enable  the multiple assessment .
   */
  is_enabled: boolean;
}
