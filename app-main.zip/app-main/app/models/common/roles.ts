export enum Roles {
  Admin = "admin",
  Superadmin = "superadmin",
  EnterpriseAdmin = "enterprise_admin",
  Manager = "manager",
  Calibrator = "calibrator",
  Coordinator = "coordinator",
  Evaluable = "evaluable",
  Evaluator = "evaluator"
}
