export interface INewCalibration {
  calibration_enabled: boolean;
  is_calibrator: boolean;
  calibrate_on_access_results?: boolean;
}
