export interface ILanguage {
  id?: number | string;
  text?: string;
  active?: boolean;
}
