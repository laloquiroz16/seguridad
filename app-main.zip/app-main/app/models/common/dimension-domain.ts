export interface IDimensionDomain {
  /**
   * @description Domain identifier
   */
  identifier: number;

  /**
   * @description The name of the Domain
   */
  name: string;
  show_in_feedback: boolean;
  show_average_card: boolean;
  dimension_id: number;
}
