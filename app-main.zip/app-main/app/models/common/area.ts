export interface IArea {
  /**
   * @description Area identifier.
   */
  id: number;

  /**
   * @description Area identifier.
   */
  area_id: number;

  /**
   * @description Name of the area.
   */
  name: string;

  /**
   * @description Parent area identifier.
   */
  parent_area_id: number;

  /**
   * @description Evaluable.
   */
  evaluable: boolean;
}
