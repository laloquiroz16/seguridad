export interface IAssessmentGoal {
  /**
   * @description can hide the add goal button.
   */
  hide_goal_button: boolean;
  /**
   * @description hide objective ponderation.
   */
  hide_objective_ponderation: boolean;
}
