export interface ITranslateString {
  es?: string;
  en?: string;
  pt?: string;
  fr?: string;
}
