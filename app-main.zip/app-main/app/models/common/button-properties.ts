export interface IButtonProperties {
  visible: boolean;
  enable: boolean;
}
