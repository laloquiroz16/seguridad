export interface IDomainList {
  /**
   * @description domain identifier
   */
  id: number;

  /**
   * @description The name of the domain
   */
  name: string;
  /**
   * @description wheter if is visible for the collaborator
   */
  visible_to_collaborator: boolean;
}
