import { IModule } from "./module";

export interface ISurvey {
  /**
   * @description Survey identifier.
   */
  id: number;

  /**
   * @description Survey identifier.
   */
  survey_id: number;

  /**
   * @description Survey name.
   */
  name: string;

  /**
   * @description Enterprise process identifier
   */
  enterprise_process_id: number;

  /**
   * @description Whether data was loaded by area. If so, the results will be directly loaded from the database.
   *
   */
  results_already_calculated: boolean;

  /**
   * @description Whether option show area/team results is enabled
   */
  enable_result_type: boolean;

  /**
   * @description Whether option comparation with another survey is enabled
   */
  enable_comparation: boolean;

  /**
   * @description Whether dimension sort by score
   */
  order_by_score: boolean;

  /**
   * @description Key indicators of the survey
   */
  key_indicators: any[];

  /**
   * @description User role in survey
   */
  role_in_survey: string;

  /**
   * @description Whether excel instructions is enabled in the results excel
   * @default false
   */
  excel_instructions: boolean;

  /**
   * @description Excel instructions content
   */
  excel_instructions_content: string;

  /**
   * @description Title of the survey
   */
  title: any;

  /**
   * @description Distribution values
   */
  distribution_values: any[];

  /**
   * @description Number of answers to take into consideration when showing results
   */
  number_answers_to_count: number;

  /**
   * @description Positive value in the survey
   */
  positive_value: any;

  /**
   * @description Type calculation of results
   */
  calculation_result_type: any;

  /**
   * @description Whether customization of the report indicator is active
   */
  apply_custom_score_formula: boolean;

  /**
   * @description Custom score formula
   */
  custom_score_formula: string;

  /**
   * @description Score style
   */
  score_style: string;

  /**
   * @description Number of decimals to report
   */
  decimal_rounding: number;

  /**
   * @description Whether report all indicators in a single file
   */
  single_file: boolean;

  /**
   * @description Id of comparison survey
   */
  survey_comparation_id: number | null;

  /**
   * @description Whether hide the qualitative questions
   */
  hide_cualitative_questions: boolean;

  /**
   * @description Hash of the survey
   * @description Whether qualitative questions are optional when answering.
   */
  optionals_cualitative_questions: boolean;

  /**
   * @description Hash of the survey
   *
   */
  survey_hash: string;

  /**
   * @description Order number of last question answered
   */
  last_answered_order: number;

  /**
   * @description  Title of the page when answering the survey
   */
  page_title: string;

  /**
   * @description  Descripcion of the page when answering the survey
   */
  page_description: string;

  /**
   * @description  Imagen of the page when answering the survey
   */
  page_image_url: string;

  /**
   * @description  Items of the survey
   */
  items: any[];

  /**
   * @description Process token
   */
  process_token: string;

  /**
   * @description survey token
   */
  token: string;

  /**
   * @description Type of the survey
   */
  survey_type: number;

  /**
   * @description Whether importation from results
   */
  only_import_results: boolean;

  /**
   * @description Start date of the survey
   */
  start_date: Date;

  /**
   * @description End date of the survey
   */
  end_date: Date;

  /**
   * @description Status of the survey
   */
  survey_state: number;

  /**
   * @description Enterprise  identifier
   */
  enterprise_id: number;

  /**
   * @description Whether can admin the survey
   */
  can_admin_process: boolean;

  /**
   * @description Whether managers can view users list
   */
  monitoring_list_users_for_managers: boolean;

  /**
   * @description Whether show result type team in results
   */
  show_team_result_type: boolean;

  /**
   * @description Survey comparator
   */
  survey_comparator: any;

  /**
   * @description The conversion enterprises information of the survey
   */
  convertion_enterprises: any[];

  /**
   * @description Information relations module
   *
   */
  module: IModule;

  /**
   * @description Whether allow download report
   */
  allow_report_download: boolean;

  /**
   * @description Indicates  if user can create actionplans
   */
  can_create_actionplans: boolean;

  /**
   * @description Indicates if actionplans module is enbaled
   */
  enabled_actionplans: boolean;

  /**
   * @description JSON - Title of the survey
   */
  title_translate: { [key: string]: any };

  /**
   * @description JSON - Description of the survey
   */
  description_translate: { [key: string]: any };

  /**
   * @description string - units char for results
   */
  score_style_unit;

  /**
   * @description boolean - allow multple periods
   */
  has_multiple_periods;

  /**
   * @description integer - amount of periods available
   */
  max_periods;

  /**
   * @description boolean - indicate if is activated sms
   */
  enable_sms;

  /**
   * @description boolean - indicate if is activated whatsapp
   */
  enable_whats_app;

  /**
   * @description number - 0: collaborators - 1: segments
   */
  participant_type;
}
