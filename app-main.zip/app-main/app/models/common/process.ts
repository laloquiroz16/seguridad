import { IModule } from "@models/common/module";
import { IDimensionDomain } from "@models/common/dimension-domain";
import { IDomainList } from "@models/common/domain-list";
import { MatrixType } from "@models/talent";
import { IResultsConfiguration } from "@models/satisfaction";
import { IAsssmentConfiguration } from "@models/common/assessment-configuration";
import { INextPeriodGoalsConfiguration } from "@models/common/next-period-goals-configuration";
import { IFeedbackConfiguration } from "@models/common/feedback-configuration";
import { INewCalibration } from "@models/common/new-calibration";

export interface IProcess {
  new_calibration: INewCalibration;
  /**
   * @description Process identifier
   */
  id: number;

  /**
   * @description The name of the process
   */
  name: string;
  /**
   * @description Whether the process has closing survey
   */
  has_closing_survey: boolean;
  /**
   * @description Whether the process allows to create private notes on collaborators feedback
   */
  has_private_notes: boolean;
  /**
   * @description Process status 0 disabled, 1 evaluation, 2 feedback, 3 result access, 4 goal setting, 5 verification, 6 Inactive, 7 calibration
   */
  status: number;
  /**
   * @description Whether the qualitatives results summary should be visible on feedback
   */
  show_qualitatives_summary: boolean;
  /**
   * @description Whether the current user has qualitative questions
   */
  has_qualitative_questions: boolean;
  /**
   * @description Whether the process has qualitative questions enabled
   */
  enabled_qualitative_questions: boolean;
  /**
   * @description Whether the process allow to create comments on feedback
   */
  has_feedback_comments: boolean;
  /**
   * @description Whether the process has objective setting enabled
   */
  enable_goals_setting: boolean;
  /**
   * @description Whether the process has action plans
   */
  has_actionplans: boolean;
  /**
   * @description Whether the objectives are hide
   */
  hide_objective: boolean;
  /**
   * @description Whether the current user has goals
   */
  has_goals: boolean;
  /**
   * @description Whether the objectives are managed
   */
  managed_objectives: boolean;
  /**
   * @description Whether the goals summary should be visible on feedback
   */
  show_goals_summary: boolean;
  /**
   * @description Whether the general summary should be visible on feedback
   */
  show_general_summary: boolean;
  /**
   * @description Whether the competences summary should be visible on feedback
   */
  show_competences_summary: boolean;
  /**
   * @description Whether the user has competences on this process
   */
  has_competences: boolean;
  /**
   * @description Whether this process has the form enabled
   */
  has_form: boolean;
  /**
   * @description Whether this process has continuous goals setting
   */
  has_family_goals: boolean;
  /**
   * @description The user role for this process
   */
  role_in_process: string;
  /**
   * @description Whether this user is an evaluator on this process
   */
  is_evaluator: boolean;
  /**
   * @description Number of decimals digits to use when showing results
   */
  results_precision: number;
  /**
   * @description Whether the process is set up to hide goals weighting
   */
  hide_goals_ponderation: boolean;
  /**
   * @description Maximum number of goals that can be created in this process per
   * assessment
   */
  max_goals: number;
  /**
   * @description Minimum number of goals that can be created in this process per
   * assessment
   */
  min_goals: number;
  /**
   * @description Minimum weighting in percentage that a goal can weight for an assessment
   */
  min_ponderation_goal: number;
  /**
   * @description Maximum weighting in percentage that a goal can weight for an assessment
   */
  max_ponderation_goal: number;
  /**
   * @description Whether the goals can be edited after the assessment has been finished
   */
  edit_goals_after_finalized: boolean;

  /**
   * @description: Defines if the current user can view results of any area in the company
   */
  can_view_results: boolean;

  /**
   * @description: Defines if the current user can view monitoring for some area in the company
   */
  user_can_view_monitoring: boolean;
  /**
   * @description Wether the assessment can be finished without any objectives
   */
  finalize_with_objectives: boolean;
  /**
   * @description Wether this assessment should validate objectives weighting
   */
  validate_objectives_ponderation: boolean;
  /**
   * @description What the list of objectives weighting should sum up to
   */
  objectives_ponderation: number;

  /**
   * @description Whether this user can create action plans for himself
   */
  allow_auto_commitments: boolean;

  /**
   * @description Whether this user can create action plans for himself
   */
  allow_modification_in_feedback: boolean;

  /**
   * @description Information relations module
   *
   */
  module: IModule;
  /**
   * @description Whether during objective setting in continuous goals the goals can be assessed
   */
  can_evaluate_in_fixation: boolean;

  /**
   * @description Stores information related to the settings of the talent matrix such as whether the X and Y axis are
   *              locked or unlocked and the matrix scales in both X and Y axis.
   */
  matrix_configuration: any;

  /**
   * @description Supplies detailed information about the layers (or leves) for a talent matrix
   *              like the names of the levels, colors, maximum and minimum values, etc.
   */
  matrix_layers: any;

  /**
   * @description Whether there is an active period for this process, returns false if no match is found.
   */
  active_period: any;
  /**
   * @description Whether the feedback survey is active
   */
  active_finalize_feedback_survey_evaluable: boolean;

  /**
   * @description Whether the continuous feedback from this process allows the access to the all public feedback feature
   */
  allow_public_feedback: boolean;
  /**
   * @description Whether the continuous feedback from this process allows to edit or delete feedbacks
   */
  allow_public_feedback_default: boolean;
  /**
   * @description Whether the feedback is public by default
   */
  allow_edit_or_delete_feedback: boolean;
  /**
   * @description This token is an uuid that identifies the process
   */
  token: string;
  /**
   * @description Whether on assessing someone on the minimum level for a competence a comment is required explaining why
   */
  required_comment_eval_min_level_competence: boolean;
  /**
   * @description Whether on assessing someone on the maximum level for a competence a comment is required explaining why
   */
  comment_required: boolean;
  /**
   * @description Whether all competences from this process should be always open
   */
  display_expanded_competences: boolean;
  /**
   * @description Show form summary in feedback
   */
  show_form_summary: boolean;
  /**
   * @description Whether the evaluation is active in the goal setting state
   */
  active_fixation_evaluation: boolean;
  /**
   * @description Whether the process has closing goal survey
   */
  has_closing_goal_survey: boolean;
  /**
   * @description Show biography in individual results
   */
  show_biography: boolean;

  /**
   * @description Domain of the process
   */
  domain: any;
  /**
   * @description Whether the process has the new feedback view enabled
   */
  new_feedback: boolean;

  /**
   * @description Whether the process is an all way assessment process
   */
  evaluation_360: boolean;
  /**
   * @description Rankmi module code of the process
   */
  rankmi_module_code: string;
  /**
   * Whether the feedback is active
   */
  active_feedback: boolean;
  /**
   * @description whether the process allow comments visible for collaborators
   */
  show_comments_goal: boolean;

  /**
   * Whether the average is hide
   */
  averages_hide: boolean;
  /**
   * Whether the general results is hide
   */
  hide_general_results: boolean;
  /**
   * Whether the objectives results is hide
   */
  hide_objectives_results: boolean;
  /**
   * Whether the competences results is hide
   */
  hide_competences_results: boolean;
  /**
   * Whether the calibration is enabled
   */
  enable_calibration: boolean;
  /**
   * Whether the distribution summary of calibration is enabled
   */
  enable_calibration_distribution: boolean;
  /**
   * Whether the matrix summary of calibration is enabled
   */
  enable_calibration_matrix: boolean;
  /**
   * define calibration type (area | collaborators)
   */
  calibration_type: string;
  /**
   * collaborators groups when calibrating people
   */
  calibration_grouped_collaborators: boolean;
  /**
   * Whether calibrate evaluables
   */
  calibrate_direct_team: boolean;
  /**
   * Whether calibrate assigned collaborators (excel assigned)
   */
  calibrate_collaborators: boolean;
  /**
   * Whether calibrate with dropdown or input (levels | numbers)
   */
  calibration_unit: string;
  /**
   * Whether calibrate only once before finalize
   */
  calibrate_more_than_once: boolean;
  /**
   * Whether calculate results when calibrating
   */
  recalculate_when_calibrating: boolean;
  /**
   * Whether enable calibration comment
   */
  enable_calibration_comment: boolean;
  /**
   * Whether mandatory comment when calibrating
   */
  comment_when_calibrating: boolean;
  /**
   * Whether mandatory comment when calibrating evaluables
   */
  comment_when_calibrating_my_team: boolean;
  /**
   * Whether calibration comment visible to evaluable
   */
  comment_visible_to_collaborator: boolean;
  /**
   * Whether individual results report is visible when calibrating
   */
  show_collaborator_report: boolean;
  /**
   * Whether expected curve is required
   */
  required_expected_curve: boolean;
  /**
   * if there is a minimum number of collaborators to make the curve mandatory
   */
  min_participant_expected_curve: number;
  /**
   * Whether collaborators calibration comment required
   */
  enable_calibration_comment_my_team: boolean;
  /**
   * Whether my team calibration comment required
   */
  comment_my_team_visible_to_collaborator: boolean;
  /**
   * Whether the levels from evaluation type is active
   */
  levels_from_evaluation_type: boolean;
  /**
   * @description Survey type
   */
  survey_type: number;
  /**
   * @description Whether this user is a validator in this process
   */
  is_validator: boolean;
  /**
   * @description Whether this user is a matrix validator in this process
   */
  is_second_validator: boolean;
  /**
   * @description Whether the process has self assessment
   */
  has_autoevaluation: boolean;
  /**
   * @description Whether the user is a verifier on this process
   */
  is_verifier: boolean;
  /**
   * @description Whether the user performs feedback
   */
  can_verify: boolean;
  perform_feedback: boolean;
  is_evaluable: boolean;
  allow_access_feedback_evaluable: boolean;
  evaluable_feedback_complete: boolean;
  allow_access_results_post_feedback: boolean;
  finalize_feedback_by_evaluable: boolean;
  can_view_monitoring: boolean;
  survey_to_answer: any;
  can_create_actionplans: boolean;
  can_view_actionplans: boolean;
  process_id: number;
  feedback_related_process_id: number;
  can_view_own_actionplans: boolean;
  survey_state: number;
  enable_autofixation_goals: boolean;
  /**
   * Whether the dimensions domains
   */
  dimensions_domains: IDimensionDomain[];
  /**
   * @description Whether assessment summary is visible
   */
  show_resume_evaluations: boolean;
  /**
   * @description Whether competences tab is visible in the assessment summary
   */
  show_evaluation_competences_resume: boolean;
  /**
   * @description Whether goals tab is visible in the assessment summary
   */
  show_evaluation_goals_resume: boolean;
  /**
   * @description Whether qualitative tab is visible in the assessment summary
   */
  show_evaluation_qualitative_resume: boolean;

  /**
   * @description Enterprise  identifier
   */
  enterprise_id: number;

  /**
   * @description Show or hide team tab for feedback process on user view
   */
  show_team_tab: boolean;

  /**
   * @description Show or hide company tab for feedback process on user view
   */
  show_company_tab: boolean;

  /**
   * @description Activate or disable option to show only first level on feedback team
   */
  all_feedbacks_first_level;

  /**
   * @description Disable or activate multiple feedbacks at same time
   */
  multiple_feedback_disabled;

  /**
   * @description Show or hide individual report of collaborator
   */
  show_individual_report_in_calibration: boolean;
  /**
   * @description  Whether is required the selfAssessment
   */
  autoevaluation_mandatory: boolean;
  /**
   * @description  Whether if it is only validated once
   */
  validate_once: boolean;
  /**
   * @description  Whether if is  enable the selfAssessment
   */
  enable_autoevaluation: boolean;
  /**
   * @description  Whether if has selfAssessment of goals
   */
  has_autoevaluation_goals: boolean;

  /**
   * @description performance matrix position
   */
  matrix_position_calculation: boolean;
  /**
   * @description  Whether if is active domains in selfAssessment
   */
  active_domains_autoevaluation: any[];
  /**
   * @description  Whether if  can show calibrated users directly
   */
  show_calibrated_users_directly: boolean;
  /**
   * @description  Whether if  can calibrate
   */
  can_calibrate: boolean;
  /**
   * @description  Whether if  is manager
   */
  is_manager: boolean;
  /**
   * @description Enable/Disable show autoevaluation for descending evaluators during evaluation.
   */
  show_autoevaluation_during_evaluation: boolean;
  /**
   * @description Whether if is enable mandatory curve
   */
  enable_mandatory_curve;

  show_average_competences_section: boolean;
  /**
   * @description Whether distribution chart is set for validation (when list validation is enabled)
   */
  enable_validation_distribution: boolean;
  /**
   * @description Whether matrix is set for validation (when list validation is enabled)
   */
  enable_validation_matrix: boolean;
  /**
   * @description Start date for the process
   */
  start_date: string;
  /**
   * @description Due date for the process
   */
  due_date: string;
  /**
   * @description Process languages
   */
  languages: any;
  /**
   * @description Whether the autoevaluation is set as private or not
   */
  private_autoevaluation: boolean;

  name_translate: any;

  description_translate: any;

  calculate_average_domains: boolean;

  resume_on_evaluation: boolean;

  show_unfinished_evavaluations_calibration: boolean;
  /**
   * @description Enable/Disable show resumen in autoevaluation
   */
  show_user_resume: boolean;

  /**
   * @description Whether the resume is required to advance in the evaluation
   */
  required_user_resume: boolean;

  /**
   * @description Enable/Disable show resume
   */

  autoevaluation_readonly_mode: boolean;

  validation_type: string;

  show_global_report: boolean;
  /**
   * @description Whether the user should go directly to "my team"
   */
  show_evaluator_comments: boolean;
  /**
   * @description Show evaluator comments to collaborator
   */
  default_tab_is_team: boolean;
  /**
   * @description This option allows to set the validation as
   * optional before proceeding to feedback
   */
  optional_validation: boolean;

  /**
   * @description Process options for sidebar menus.
   */
  process_menus: any[];
  /**
   * @description Visibility state for comparison chart on feedback individual report.
   */
  show_comparison_chart: boolean;
  /**
   * @description Comparison chart config options object.
   */
  comparison_chart_options: any;
  /**
   * @description Whether enable commitment template by family competence
   */
  enabled_commitment_template_by_fcompetence: boolean;

  // master sync configuration
  syncronize_participants_positions: boolean;
  syncronize_participants_area: boolean;

  matrix_available_to_list: boolean;
  matrix_available_to_summary: boolean;
  matrix_available_to_dispersion: boolean;
  show_user_profile: boolean;
  show_user_x_axis: boolean;
  show_user_y_axis: boolean;
  show_user_matrix_position: boolean;
  talent_calibrate_configurations: any;
  talent_performance_process_domain_id: number;
  talent_performance_process_id: number;
  talent_matrix_type: MatrixType;

  /**
   * @description check if all evaluations of user are completed
   */
  evaluations_completed: boolean;

  /**
   * @description Whether disabled the goals accomplishment
   */
  hide_goals_accomplishment: boolean;

  /**
   * @description wheter the list domains of process
   */
  domains_list: IDomainList[];
  /**
   * @description wheter if  hide scales in report
   */
  hide_scales_feedback_report: boolean;
  related_processes_list: IProcess[];
  /**
   * @description Show calibration direct access
   * when all evaluations are completed and this option is enabled.
   */
  show_calibration_access_on_evaluation: boolean;
  /**
   * @description Show autoevaluation results for validator when option it's enabled.
   */
  show_autoevaluation_for_validator: boolean;
  /**
   * @description whether enable the new digital report
   */
  enable_digital_report;
  /**
   * @description whether if exist configurations for report digital
   */
  has_report_configurations: boolean;
  /**
   * @description Enable or disable the general distribution chart for evaluation teams.
   */
  enable_general_distribution: boolean;
  /**
   * @description Enable or disable the curve on evaluation distribution chart.
   */
  enable_general_curve: boolean;
  /**
   * @description Enable or disable the comment button.
   */
  show_comment_button: boolean;
  /**
   * @description Enable or disable the evaluation scales on pdf reports.
   */
  show_pdf_evaluation_scales: boolean;
  /**
   * @description Enable or disable the pdf competences comments.
   */
  show_pdf_conduct_comments: boolean;
  /**
   * @description Show bars for all results within individual results and all its associated components (Summary, Competences)
   */
  show_report_bars: boolean;

  show_individual_reports_card_template: boolean;

  show_competence_average_only: boolean;

  show_final_average_only: boolean;
  /**
   * @description Show or hide the name of the group in group calibration
   */
  show_calibration_group_name: boolean;

  /**
   * @description Evaluable user can access verification
   */
  show_verification_evaluables: boolean;
  /**
   * @description Evaluator user can access verification
   */
  show_verification_evaluators: boolean;
  /**
   * @description Show goals' scale in result view when option it's enabled.
   */
  show_goals_scale: boolean;
  /**
   * @description Show competences' scale in result view when option it's enabled.
   */
  show_competences_scale: boolean;
  /**
   * @description Show or hide the reference link in objectives goals results [feedback]
   */
  show_reference_link_on_goals_results: boolean;

  /**
   * @description Atributes to results configuration in Satisfaction
   */
  satisfaction_results_configuration_attributes: IResultsConfiguration;
  /**
   * @description Atributes to satisfaction_distribution_scale configuration in Satisfaction
   */
  satisfaction_distribution_scale_attributes: any[];
  /**
   * @description Atributes to satisfaction_distribution_scale configuration in Satisfaction
   */
  satisfaction_general_distribution_scale_attributes: any[];
  /**
   * @description Atributes configuration in Satisfaction
   */
  satisfaction_configuration_attributes: any;
  /**
   * @description  Whether if can assessment before of signing
   */
  can_assessment_goal_before_signing: boolean;

  dimensions: string[];
  /**
   * @description  Whether to display the averages column in the evaluation table when the process is in goals fixation
   */
  display_general_averages: boolean;
  /**
   * @description Whether this change resets assessment statuses
   */
  change: boolean;
  /**
   * @description Whether the configuration of multiple assessment
   */
  assessment_configuration: IAsssmentConfiguration;
  /**
   * @description Continuous Goal Configuration object.
   */
  goal_setting_configuration: any;
  /**
   * @description Allow to finish feedback if evaluation has finish goals finished.
   */
  can_finish_feedback_after_fixation: boolean;

  recent_feedback_show: number;
  /**
   * @description Calibration configuration object.
   */
  calibration_configuration: any;
  /**
   * @description Coordination configuration object.
   */
  coordination_configuration: any;
  /**
   * @description If true, all question must be answered in order to complete a feedback
   */
  require_all_feedback_answers: boolean;
  show_resume: boolean;
  evaluator_has_evaluables: boolean;
  can_verify_evaluables: boolean;
  has_evaluators: boolean;
  has_verification: boolean;
  show_self_goals: boolean;
  team_confirmed: boolean;
  verified: boolean;
  process_has_validation: boolean;
  has_validation_matricial: boolean;
  can_calibrate_final_calibration: boolean;
  can_feedback_on_calibration: boolean;
  is_coordinator: boolean;
  show_add_and_delete_buttons_in_verification: boolean;
  next_period_goals_configuration: INextPeriodGoalsConfiguration;
  feedback_configuration: IFeedbackConfiguration;
  assessment_goal: any;
  can_manager_admin: boolean;

  /**
   * @description Talent matrix discrete mode
   */
  matrix_autoloaded: boolean;
  show_report_objectives_unit: boolean;

  show_average_progress_bar: boolean;
  show_feedback_mandatory_in_evaluation: boolean;

  verification_code: string;
  fixation: boolean;
  restrict_access_for_evaluations: boolean;
  feedback_mandatory_access_result: boolean;
  evaluator_feedback_finished: boolean;
  restrict_results_for_evaluators_and_evaluables: boolean;

  /**
   * @description Wether the new monitoring is activated in the process configuration
   */
  show_new_monitoring: boolean;

  form_mandatory: boolean;
  /** @description These settings manipulate the display of the score in goal evaluation */
  show_goal_average_only?: boolean;
  /** @description These settings manipulate the display of the label in goal evaluation */
  show_goal_average_label_only?: boolean;
  /** @description These settings manipulate the display of the unit in goal evaluation */
  show_goal_average_unit_only?: boolean;

  enable_general_distribution_in_evaluation_list: boolean;

  /**
   * @description Stores the settings for the succession tree related to the process.
   */
  succession_tree_settings: any;

  enterprise_login_information: number;

  /**
   * @description Whether this process is a import result process
   */
  only_import_results: boolean;
  resume_finished: any;
  evaluator_with_verification: boolean;
  validated_user: boolean;
}
