interface ICollaboratorInfo {
  id: number;
  name: string;
  avatar: string;
  identifier?: string;
  position: string;
  area?: string;
  token?: string;
}
export default ICollaboratorInfo;
