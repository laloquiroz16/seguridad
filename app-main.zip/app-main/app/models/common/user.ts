export interface IUser {
  /**
   * @description User identifier
   */
  id: number;

  /**
   * @description User avatar
   */
  user_avatar: string;

  /**
   * @description User checked
   */
  checked: boolean;

  /**
   * @description Invitation status
   */
  invitation_status: number;

  /**
   * @description Survey status
   */
  survey_status: number;

  /**
   * @description Pair x,y in a Talent Matrix
   */
  position_in_matrix: any;
}

/** @description Interface to User model of the back-end */
export interface IUserAllInfo {
  id: number;
  name: string;
  lastname: string;
  email: string;
  identifier: string;
  birthdate: string;
  joining_date: string;
  created_at: string;
  updated_at: string;
  avatar_file_name: any;
  avatar_content_type: any;
  avatar_file_size: any;
  avatar_updated_at: any;
  gender: string;
  enterprise_position_id: number;
  country_id: any;
  rut: string;
  evaluator_id: any;
  evaluator_identifier: any;
  has_autoevaluation: false;
  validator_identifier: any;
  validator_id: any;
  middle_name: string;
  mothers_name: string;
  evaluation_progress_intro: false;
  evaluation_intro: false;
  confirmed_evaluator: true;
  user_has_confirmed: false;
  in_engagement: any;
  in_performance: any;
  bulk_import_enterprise_id: any;
  leader_id: any;
  token: string;
  lang: string;
  exclude_search: false;
  have_successor: any;
  direct_manager_id: number;
  area: string;
  function: any;
  unit: any;
  phone: any;
  address: string;
  biography: string;
  linkedin: string;
  facebook: string;
  twitter: string;
  instagram: any;
  skip_email: false;
  master_avatar_url: any;
  avatar_url: any;
}
