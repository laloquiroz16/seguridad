export interface IFeedbackConfiguration {
  id: number;
  allow_new_score: boolean;
}
