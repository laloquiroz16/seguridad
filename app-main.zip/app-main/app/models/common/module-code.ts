export enum ModuleCode {
  Engagement = "rkm_03",
  Performance = "rkm_01",
  Talent = "rkm_04",
  GreatPlaceToWork = "rkm_02",
  ContinuousFeedback = "rkm_05",
  Satisfaction = "rkm_06",
  OpenSurvey = "rkm_12"
}
