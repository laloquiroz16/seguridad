export interface IDimension {
  /**
   * @description Dimension identifier
   */
  id: number;

  /**
   * @description The name of the dimension
   */
  name: string;

  /**
   * @description The type of the dimension
   */
  dimension_type: string;
}
