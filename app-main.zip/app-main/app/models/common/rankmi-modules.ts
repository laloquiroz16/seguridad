export enum RankmiModules {
  Engagement = "engagement",
  Performance = "performance",
  Talent = "talent",
  ContinuousFeedback = "continuous_feedback",
  Satisfaction = "satisfaction",
  organizationChart = "organization_chart",
  Gptw = "gptw",
  OpenSurvey = "open_survey"
}
