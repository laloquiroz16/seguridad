export interface ITabConfiguration {
  id: any;
  title: string;
  visible: boolean;
  active: boolean;
}
