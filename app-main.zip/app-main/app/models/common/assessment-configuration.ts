import { IMultipleAssessment } from "@models/common/multiple-assessment";
import { IAssessmentGoal } from "@models/common/assessment-goal";

export interface IAsssmentConfiguration {
  /**
   * @description assessment configuration identifier.
   */
  id: number;
  /**
   *  @description related feedback process privacy.
   */
  related_feedback_private: boolean;

  /**
   * @description Area identifier.
   */
  multiple_assessment: IMultipleAssessment;
  assessment_goal: IAssessmentGoal;
}
