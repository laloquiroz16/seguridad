export enum Words {
  Plural = "plural",
  Singular = "singular"
}
