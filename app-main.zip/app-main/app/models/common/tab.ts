export interface ITab {
  /**
   * @description The tab identifier, this must be unique in the array, since it's used in the track by expression
   * @throws Duplicates in a repeater are not allowed
   * @see {@link https://docs.angularjs.org/error/ngRepeat/dupes}
   */
  id: any;
  /**
   * @description Active status on the array of tabs
   */
  active: boolean;
  /**
   * @description Wether this tab has an error to alert the user
   */
  hasError?: boolean;
  /**
   * @description ng-style object to be applied to the tab
   */
  style?: any;
  /**
   * @description The label that will be shown in the view
   */
  text: string;
  /**
   * @description An icon to be placed as a prefix of the text
   */
  icon?: string;
  /**
   * @description If needed a description of the tab that will be placed in a tooltip to the right
   */
  information?: {
    title?: string;
    description?: string;
    classDescription?: string;
  };
}
