export interface IEnterpriseHomeProcess {
  token: string;
  title: string;
  status: number | null;
  code: "rkm_01" | "rkm_02" | "rkm_03" | "rkm_04" | "rkm_06" | "rkm_12";
  domain: string;
  due_date: Date | null;
  progress: number;
  type: "process" | "survey";
  process_id: number;
  survey_id: number | null;
  active_period: number;
  show_id: number | null;
}
