export interface IEnterpriseFilterProcessType {
  id: string;
  title: string;
  code: string | null;
  domain: string | null;
}
