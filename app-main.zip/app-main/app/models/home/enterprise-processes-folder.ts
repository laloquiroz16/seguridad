import { IApiTranslation } from "@models/home/api-translation";

export interface IEnterpriseProcessesFolder {
  name: string | IApiTranslation;
  description: string | IApiTranslation;
  color: string | null;
  show_on_processes_section: boolean;
  token: string;
  type: "custom" | "default";
  order: number;
  processes: Array<{ token: string; title: string; order: number }>;
}
