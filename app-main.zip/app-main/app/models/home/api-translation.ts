export interface IApiTranslation {
  es: string | null;
  en: string | null;
  fr: string | null;
  pt: string | null;
  de: string | null;
  pl: string | null;
}
