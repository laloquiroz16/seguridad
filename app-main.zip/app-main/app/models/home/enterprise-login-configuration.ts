import { IApiTranslation } from "@models/home";

export interface IEnterpriseLoginConfiguration {
  head_translate: IApiTranslation;
  help_information_translate: IApiTranslation;
  name: string;
  logo: any;
  white_logo: any;
  navbar_background: string;
  include_email_recovery: boolean;
  custom_domain: string;
  headline: string;
  allow_google_signin: boolean;
  allow_azure_active_directory_signin: boolean;
  allow_generic_sso_signin: boolean;
  login_type: any;
  allow_form_user_pass: boolean;
  allow_keycloak_signin: boolean;
  enable_master_auth: boolean;
}
