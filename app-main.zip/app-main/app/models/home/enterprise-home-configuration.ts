export interface IEnterpriseHomeConfiguration {
  /**
   * Show anonymous user home page
   */
  anonymous_mode: boolean;

  /**
   * Show process list
   */
  show_process: boolean;

  /**
   * Active session
   */
  active_session: boolean;
}
