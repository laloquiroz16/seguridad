import { JWT } from "@src/auth/models";
import { Expose, Transform } from "class-transformer";

export class MasterEnterpriseHomeConfiguration {
  @Expose({ name: JWT.SessionExpirationEnabled, toClassOnly: true })
  sessionExpirationEnabled: boolean;

  @Expose({ name: JWT.FinishSessionSeconds, toClassOnly: true })
  @Transform(value => value / 60, { toClassOnly: true })
  @Transform(value => value * 60, { toPlainOnly: true })
  finishSessionSeconds: number;

  @Expose({ name: "jwt_duration_hours", toClassOnly: true })
  jwtDurationHours: number;
}
