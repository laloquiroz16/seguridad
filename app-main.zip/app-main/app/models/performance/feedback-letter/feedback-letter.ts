import { Expose } from "class-transformer";

export class FeedbackLetter {
  @Expose({ name: "letterhead" })
  letterhead: any;
  @Expose({ name: "action_plans" })
  actionPlans: any;
  @Expose({ name: "average" })
  average: any;
  @Expose({ name: "feedback_comment" })
  feedbackComment: any;
  @Expose({ name: "goals" })
  goals: any;
  @Expose({ name: "autoevaluation_competences" })
  autoevaluationCompetences: any;
  @Expose({ name: "conducts_ranking" })
  conductsRanking: any;
  @Expose({ name: "form_questions" })
  formQuestions: any;
  @Expose({ name: "coordination_survey" })
  coordinationSurvey: any;
}
