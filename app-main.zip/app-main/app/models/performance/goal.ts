import { IGoalLabel } from "@models/performance/goal-label";

export interface IGoal {
  /**
   * @description Goal identifier
   */
  id: number;
  /**
   * @description Date when this goal has to be completed
   */
  duedate: Date;
  /**
   * @description Likert evaluation type id
   */
  evaluation_type_id: number;
  /**
   * @description Whether this goal can be assessed
   */
  evaluable: boolean;
  /**
   * @description Goal evaluation type
   */
  evaluation_type: string;
  /**
   * @description Goal score
   */
  score: number;
  /**
   * @description Goal comment
   */
  comment: string;
  /**
   * @description The array of available score for behaviour goal type
   */
  labels: IGoalLabel[];
  /**
   * @description Goal weighting for the objective it belongs
   */
  ponderation: number;
  /**
   * @description On an achievement type of goal this is the accomplished label
   */
  achievement_label: string;
  /**
   * @description This is the total score for an achievement goal
   */
  achievementScore: number;
  /**
   * @description Goal setup
   */
  metadata: any;
  /**
   * @description indicates whether the goal was imported from a file
   */
  imported: boolean;
  /**
   * @description autoevaluation accomplishment
   */
  autoevaluation_accomplishment: any;
  editable: boolean;
  replication_can_be_removed: boolean;
  fixed: boolean;
  edit_goal_ponderation: boolean;
  likert_label: string;
  expected_value: any;
  linear_interpolation?: any;
}
