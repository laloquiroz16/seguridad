import { Expose } from "class-transformer";

export class AssessmentMenu {
  id: number;
  name: string;

  @Expose({ name: "calibration_visible" })
  isCalibrationVisible: boolean;

  @Expose({ name: "coordination_visible" })
  isCoordinationVisible: boolean;

  @Expose({ name: "evaluation_visible" })
  isAssessmentVisible: boolean;

  @Expose({ name: "feedback_visible" })
  isFeedbackVisible: boolean;

  @Expose({ name: "instructions_visible" })
  isInstructionsVisible: boolean;

  @Expose({ name: "resume_visible" })
  isResumeVisible: boolean;

  @Expose({ name: "validation_visible" })
  isValidationVisible: boolean;

  @Expose({ name: "verification_visible" })
  isVerificationVisible: boolean;
}
