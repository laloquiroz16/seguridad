export enum AssessmentFormInputTypes {
  FormText = "form_text",
  FormDropdown = "form_dropdown",
  FormLikert = "form_likert",
  FormInput = "form_input",
  FormSelectMultiple = "form_select_multiple",
  FormSelectSimple = "form_select_simple",
  FormTextCompetences = "form_text_competences",
  FormTextDual = "form_text_dual"
}
