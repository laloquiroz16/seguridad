export interface IEnterpriseFeedbackValue {
  id: number;
  name_translate: { [key: string]: string };
}
