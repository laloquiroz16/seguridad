import { Expose } from "class-transformer";

export class ConfigurationGoal {
  id: number;

  @Expose({ name: "user_can_only_read" })
  userCanOnlyRead: boolean;

  @Expose({ name: "add_comment" })
  addComment: boolean;

  @Expose({ name: "can_create_goal" })
  canCreateGoal: boolean;

  @Expose({ name: "can_delete_goal" })
  canDeleteGoal: boolean;

  @Expose({ name: "can_create_objective" })
  canCreateObjective: boolean;

  @Expose({ name: "can_edit_goal" })
  canEditGoal: boolean;

  @Expose({ name: "can_edit_objectives" })
  canEditObjectives: boolean;

  @Expose({ name: "can_delete_objective" })
  canDeleteObjective: boolean;

  @Expose({ name: "can_see_comment" })
  canSeeComment: boolean;

  @Expose({ name: "enable_finish_button" })
  enableFinishButton: boolean;

  @Expose({ name: "finish_button_label" })
  finishButtonLabel: string;

  @Expose({ name: "min_amount_obj" })
  minAmountObj: number;

  @Expose({ name: "max_amount_obj" })
  maxAmountObj: number;

  @Expose({ name: "min_weighing_goal" })
  minWeighingGoal: string;

  @Expose({ name: "max_weighing_goal" })
  maxWeighingGoal: string;

  @Expose({ name: "reject_button_label" })
  rejectButtonLabel: string;

  @Expose({ name: "show_create_when_no_max_weight" })
  showCreateWhenNoMaxWeight: boolean;

  @Expose({ name: "show_goal_weight" })
  showGoalWeight: boolean;

  @Expose({ name: "show_objective" })
  showObjective: boolean;

  @Expose({ name: "show_rejected_button" })
  showRejectedButton: boolean;

  @Expose({ name: "user_has_actions" })
  userHasActions: boolean;

  @Expose({ name: "validate_weighing_goal" })
  validateWeighingGoal: boolean;

  @Expose({ name: "validate_weighing_obj" })
  validateWeighingObj: boolean;

  @Expose({ name: "stage_has_survey" })
  stageHasSurvey: boolean;

  @Expose({ name: "can_answer_form" })
  canAnswerForm: boolean;

  @Expose({ name: "forms_are_hidden" })
  formsAreHidden: boolean;

  @Expose({ name: "can_evaluate" })
  canEvaluate: boolean;

  @Expose({ name: "can_modify_compliance" })
  canModifyCompliance: boolean;

  @Expose({ name: "can_reply" })
  canReply: boolean;

  @Expose({ name: "can_distribute_weight" })
  canDistributeWeight: boolean;

  @Expose({ name: "can_distribute_weight_objectives" })
  canDistributeWeightObjectives: boolean;

  @Expose({ name: "can_edit_attachment" })
  canEditAttachment: boolean;

  @Expose({ name: "show_notification_button" })
  showNotificationButton: boolean;

  @Expose({ name: "validate_final_stage_changes" })
  validateFinalStageChanges: boolean;

  @Expose({ name: "have_copy_configuration" })
  have_copy_configuration: boolean;

  @Expose({ name: "is_second_to_last_stage" })
  is_second_to_last_stage: boolean;

  @Expose({ name: "is_final_stage" })
  is_final_stage: boolean;

  @Expose({ name: "process_name" })
  process_name: string;
}

export class ConfigurationGoalFeedback extends ConfigurationGoal {
  @Expose({ name: "assessment_id" })
  assessmentId: number;
}
