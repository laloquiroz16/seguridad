export interface IAssociatedFeedbackResponse {
  data: IAssociatedFeedback[];
  meta: {
    current_page: number;
    next_page: number;
    prev_page: number;
    total_count: number;
    total_pages: number;
  };
}

export interface IAssociatedFeedback {
  id: number;
  answers: Array<{
    id: number;
    answer_type: string;
    content: string;
    question: string;
  }>;
  comments: [];
  competences: [];
  competences_and_values: Array<{
    id: number;
    description: string;
    name: string;
    type: string;
  }>;
  created_at: string;
  feedback_type: string;
  giver: {
    id: number;
    area: string;
    avatar: string;
    email: string;
    firstname: string;
    groups: [];
    identifier: string;
    lastname: string;
    middlename: string;
    mothername: string;
    position: string;
  };
  reactions: any;
  receiver: {
    id: number;
    area: string;
    avatar: string;
    email: string;
    firstname: string;
    groups: [];
    identifier: string;
    lastname: string;
    middlename: string;
    mothername: string;
    position: string;
  };
  receiver_manager: any;
  request_for_collaborators: boolean;
  request_for_public: boolean;
  star_rating: any;
  values: Array<{
    id: number;
    description: string;
    name: string;
    type: string;
  }>;
}
