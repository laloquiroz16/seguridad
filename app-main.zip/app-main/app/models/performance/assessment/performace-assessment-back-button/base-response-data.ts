export interface BaseResponseData {
  status: number;
  errors: string[];
}
