import { BaseResponseData } from "./base-response-data";

export interface BaseResponse {
  status: string;
  data: BaseResponseData | string;
}
