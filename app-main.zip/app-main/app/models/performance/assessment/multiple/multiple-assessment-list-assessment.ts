import { MultipleAssessmentCollaborator } from "@models/performance/assessment/multiple/multiple-assessment-collaborator";
import { Expose, Type } from "class-transformer";
import { CommentBasic } from "@models/common/comment";

interface IAnswer {
  score: number;
  id: number;
}

export class MultipleAssessmentListAssessment {
  @Type(() => MultipleAssessmentCollaborator)
  collaborator: MultipleAssessmentCollaborator;

  answer: IAnswer;
  @Type(() => CommentBasic)
  comment: CommentBasic;

  @Expose({ name: "is_enabled" })
  isEnabled: boolean;

  @Expose({ name: "has_pending_request" })
  hasPendingRequest: boolean;
}
