import { Expose } from "class-transformer";

export class MultipleAssessmentFinish {
  @Expose({ name: "has_more_items" })
  hasMoreItems: boolean;
}
