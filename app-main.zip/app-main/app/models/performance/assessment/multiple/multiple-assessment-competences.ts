import { Exclude } from "class-transformer";
import { MultipleAssessmentConduct } from "@models/performance/assessment/multiple/multiple-assessment-conduct";

export class MultipleAssessmentCompetences {
  id: number;
  description: string;
  name: string;
  conducts: number[] = [];

  @Exclude({ toPlainOnly: true })
  isOpen: boolean = false;

  @Exclude({ toPlainOnly: true })
  domainId?: number;

  @Exclude({ toPlainOnly: true })
  conductList?: MultipleAssessmentConduct[] = [];

  getConductCompleted(): number {
    return this.conductList.filter(({ isCompleted }) => isCompleted).length;
  }
}
