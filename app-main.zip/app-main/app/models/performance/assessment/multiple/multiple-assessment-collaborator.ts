export class MultipleAssessmentCollaborator {
  id: number;
  name: string;
  position: string;
  avatar: string;
}
