import { Expose } from "class-transformer";

export class MultipleAssessmentPanelInformation {
  name: string;

  @Expose({ name: "total_collaborators" })
  totalCollaborators: number;
}
