import { MultipleAssessmentLevel } from "@models/performance/assessment/multiple/multiple-assessment-level";
import { Exclude, Expose, Type } from "class-transformer";
import { MultipleAssessmentListAssessment } from "@models/performance/assessment/multiple/multiple-assessment-list-assessment";

export class MultipleAssessmentConduct {
  id: number;
  name: string;

  @Expose({ name: "is_completed" })
  isCompleted: boolean;

  @Type(() => MultipleAssessmentLevel)
  levels: MultipleAssessmentLevel[] = [];

  @Exclude({ toPlainOnly: true })
  competenceId?: number;

  @Exclude({ toPlainOnly: true })
  listAssessment: MultipleAssessmentListAssessment[] = [];
}
