import { Expose, Type } from "class-transformer";
import { MultipleAssessment } from "@models/performance/configuration";
import { MultipleAssessmentConfiguration } from "./multiple-assesment-configuration";

export class MultipleAssessmentProcess {
  id: number;
  name: string;

  @Type(() => MultipleAssessment)
  @Expose({ name: "multiple_assessment" })
  multipleAssessment: MultipleAssessment;

  @Expose({ name: "assessment_configuration" })
  @Type(() => MultipleAssessmentConfiguration)
  assessmentConfiguration: MultipleAssessmentConfiguration;
}
