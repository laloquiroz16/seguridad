import { Expose } from "class-transformer";

export class MultipleAssessmentConfiguration {
  @Expose({ name: "comments_min_length" })
  commentsMinLength: number;
  @Expose({ name: "require_comment_minimum_lvl" })
  requireCommentMinimumLvl: boolean;
  @Expose({ name: "require_comment_highest_lvl" })
  requireCommentHighestLvl: boolean;
  @Expose({ name: "enable_comment_buttons" })
  enableCommentButtons: boolean;
}
