export class MultipleAssessmentLevel {
  id: number;
  score: number;
  label: string;
}
