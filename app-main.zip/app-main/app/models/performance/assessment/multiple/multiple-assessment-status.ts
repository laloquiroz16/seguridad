import { Expose, Type } from "class-transformer";

export class MultipleAssessmentCompleted {
  @Expose({ name: "is_completed" })
  isCompleted: boolean = true;
}
export class MultipleAssessmentStatus {
  @Type(() => MultipleAssessmentCompleted)
  conduct: MultipleAssessmentCompleted;
  @Type(() => MultipleAssessmentCompleted)
  domain: MultipleAssessmentCompleted;
}
