import { Exclude, Expose } from "class-transformer";
import { MultipleAssessmentCompetences } from "@models/performance/assessment/multiple/multiple-assessment-competences";

export class MultipleAssessmentDomain {
  id: number;
  name: string;

  @Expose({ name: "is_completed" })
  isCompleted: boolean;

  @Exclude({ toPlainOnly: true })
  isSelected: boolean = false;

  @Exclude({ toPlainOnly: true })
  competences: MultipleAssessmentCompetences[] = [];
}
