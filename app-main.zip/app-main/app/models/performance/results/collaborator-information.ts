import { Expose } from "class-transformer";
import { CollaboratorType } from "@models/performance/configuration";

export class CollaboratorInformation {
  id: number;

  name: string;

  area: string;

  @Expose({ name: "avatar_url" })
  avatar: string;

  @Expose({ name: "enterprise_position_name" })
  position: string;

  @Expose({ name: "type_collaborator" })
  collaboratorType: CollaboratorType;

  getCollaboratorTranslate() {
    return `performance.reporting.individual.profile.${this.collaboratorType}`;
  }
}
