export class EvaluableGoals {
  id: number;
  token: string;
  feedback_completed: boolean;
}
