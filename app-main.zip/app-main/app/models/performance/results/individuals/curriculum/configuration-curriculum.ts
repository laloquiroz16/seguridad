export class ConfigurationCurriculum {
  id: number;
  required_user_resume: boolean;
  show_user_resume_details: boolean;
  languages: any[];
  team_confirmed: boolean;
  has_verification: boolean;
}
