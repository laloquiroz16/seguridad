export class EvaluableCurriculum {
  id: number;
  token: string;
  joining_date: any;
  user_avatar: string;
  name: string;
  lastname: string;
  position: string;
  rut: string;
  age: number;
  email: string;
  area;
  toggle_enterprise_subdomains;
  subdomain;
  have_successor;
}
