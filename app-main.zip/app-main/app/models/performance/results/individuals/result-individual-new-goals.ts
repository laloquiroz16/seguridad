import {
  ResultCompetence,
  ResultAverageProperty
} from "@models/performance/results";
import { Type } from "class-transformer";
import { isEmpty } from "lodash-es";

export class ResultIndividualNewGoals {
  @Type(() => ResultAverageProperty)
  general: ResultAverageProperty;

  @Type(() => ResultCompetence)
  goals: ResultCompetence;

  hasDataProperties(): boolean {
    return this.hasDataGeneral() || this.hasDataGoals();
  }

  hasDataGeneral(): boolean {
    return !isEmpty(this.general);
  }

  hasDataGoals(): boolean {
    return (
      !isEmpty(this.goals) &&
      (!isEmpty(this.goals.result) || !!this.goals.categories.length)
    );
  }
}
