export class ResultIndividualPdfConfiguration {
  id: number;
  name: string;
  type: string;
}
