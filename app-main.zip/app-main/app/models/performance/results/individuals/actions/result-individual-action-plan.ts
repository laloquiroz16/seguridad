import { Expose } from "class-transformer";
import { Button } from "@models/common/button";

export class ResultIndividualActionPlan extends Button {
  @Expose({ name: "can_create" })
  canCreate: boolean;
}
