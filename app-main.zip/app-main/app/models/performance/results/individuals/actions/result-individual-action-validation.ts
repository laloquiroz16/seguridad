import { Type } from "class-transformer";
import { Button } from "@models/common/button";

export class ResultIndividualActionValidation {
  @Type(() => Button)
  accept: Button;
  @Type(() => Button)
  reject: Button;
}
