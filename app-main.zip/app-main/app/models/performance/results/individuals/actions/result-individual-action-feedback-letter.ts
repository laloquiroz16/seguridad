import { Button } from "@models/common/button";
import { Expose } from "class-transformer";

export class ResultIndividualActionFeedbackLetter extends Button {
  @Expose({ name: "can_edit" })
  canEdit: boolean;
}
