import { Button } from "@models/common/button";
import { Expose, Type } from "class-transformer";
import { ResultIndividualActionPlan } from "@models/performance/results/individuals/actions/result-individual-action-plan";
import { ResultIndividualActionDownload } from "@models/performance/results/individuals/actions/result-individual-action-download";
import { ResultIndividualActionValidation } from "@models/performance/results/individuals/actions/result-individual-action-validation";
import { ResultIndividualActionFeedback } from "@models/performance/results/individuals/actions/result-individual-action-feedback";
import { ResultIndividualActionFeedbackLetter } from "@models/performance/results/individuals/actions/result-individual-action-feedback-letter";

export class ResultIndividualActions {
  @Expose({ name: "feedback_finish" })
  @Type(() => ResultIndividualActionFeedback)
  feedbackFinish: ResultIndividualActionFeedback;

  @Expose({ name: "feedback_letter" })
  @Type(() => ResultIndividualActionFeedbackLetter)
  feedbackLetter: ResultIndividualActionFeedbackLetter;

  @Type(() => ResultIndividualActionValidation)
  validation: ResultIndividualActionValidation;

  @Expose({ name: "coordination_finish" })
  @Type(() => Button)
  coordinationFinish: Button;

  @Expose({ name: "action_plans_create" })
  @Type(() => ResultIndividualActionPlan)
  actionPlans: ResultIndividualActionPlan;

  @Expose({ name: "assessment_modify" })
  @Type(() => Button)
  assessmentModify: Button;

  @Expose({ name: "download_report" })
  @Type(() => ResultIndividualActionDownload)
  downloadReport: ResultIndividualActionDownload;

  @Expose({ name: "notes_create" })
  @Type(() => Button)
  notesCreate: Button;
}
