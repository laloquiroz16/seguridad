import { Button } from "@models/common/button";
import { Expose } from "class-transformer";

export class ResultIndividualActionFeedback extends Button {
  @Expose({ name: "active_email_feedback" })
  activeEmailFeedback: boolean;

  @Expose({ name: "enabled_finish_feedback_message" })
  enabledFinishFeedbackMessage: boolean;

  @Expose({ name: "evaluable_answer_survey" })
  evaluableAnswerSurvey: boolean;

  @Expose({ name: "verification_code" })
  verificationCode: boolean;

  @Expose({ name: "can_finish_evaluable" })
  canFinishEvaluable: boolean;

  @Expose({ name: "feedback_survey_id" })
  feedbackSurveyId: number;

  @Expose({ name: "can_notify_boss" })
  canNotifyBoss: boolean;

  @Expose({ name: "joint_review_finished" })
  jointReviewFinished: boolean;

  @Expose({ name: "assessment_completed" })
  assessmentCompleted: boolean;

  @Expose({ name: "enable_feedback_questions_by_evaluable" })
  enableFeedbackQuestionsByEvaluable: boolean;

  @Expose({ name: "enable_feedback_message_mode_given" })
  enableFeedbackMessageModeGiven: boolean;
}
