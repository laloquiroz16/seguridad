import { Expose, Type } from "class-transformer";
import { Button } from "@models/common/button";
import { ResultIndividualPdfConfiguration } from "@models/performance/results/individuals/actions/result-individual-pdf-configuration";

export class ResultIndividualActionDownload extends Button {
  @Expose({ name: "pdf_reports" })
  @Type(() => ResultIndividualPdfConfiguration)
  pdfReports: ResultIndividualPdfConfiguration[] = [];
  @Expose({ name: "can_download_summary" })
  canDownloadSummary?: boolean;
  @Expose({ name: "can_download_extended" })
  canDownloadExtended?: boolean;
}
