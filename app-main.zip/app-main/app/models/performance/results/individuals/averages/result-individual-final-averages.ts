import { Expose, Type } from "class-transformer";
import { ResultDomainAverage } from "@models/performance/results";

export class ResultIndividualFinalAverages {
  @Expose({ name: "evaluation_domain" })
  @Type(() => ResultDomainAverage)
  generalDomain: ResultDomainAverage;

  @Expose({ name: "autoevaluation_domain" })
  @Type(() => ResultDomainAverage)
  selfAssessmentDomain: ResultDomainAverage;
}
