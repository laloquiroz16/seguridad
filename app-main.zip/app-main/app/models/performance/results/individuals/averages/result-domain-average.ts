import {
  ResultCompetence,
  ResultAverageProperty,
  ResultGoal
} from "@models/performance/results";
import { Type } from "class-transformer";
import { isEmpty } from "lodash-es";
import { ResultDomain } from "@models/performance/results/result-domain";

export class ResultDomainAverage extends ResultDomain {
  @Type(() => ResultAverageProperty)
  general: ResultAverageProperty;

  @Type(() => ResultCompetence)
  competence: ResultCompetence;

  @Type(() => ResultGoal)
  goal: ResultGoal;

  hasDataProperties(): boolean {
    return (
      this.hasDataGeneral() || this.hasDataGoal() || this.hasDataCompetence()
    );
  }

  hasDataGeneral(): boolean {
    return !isEmpty(this.general);
  }
  hasDataGoal(): boolean {
    return (
      !isEmpty(this.goal) &&
      (!isEmpty(this.goal.result) || !isEmpty(this.goal.categories))
    );
  }
  hasDataCompetence(): boolean {
    return (
      !isEmpty(this.competence) &&
      (!isEmpty(this.competence.result) || !!this.competence.categories.length)
    );
  }

  translateCompetenceGeneral(): string {
    return this.default
      ? "performance.reporting.global.promediosGenerales.body.lbl3"
      : "performance.evaluation.feedback.individual_report.summary.competences.title";
  }
}
