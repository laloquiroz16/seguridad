import { Expose } from "class-transformer";

export class NoteAuthor {
  id: number;
  name: string;
  lastname: string;
  @Expose({ name: "user_avatar" })
  userAvatar: string;

  getCompleteName() {
    return `${this.name} ${this.lastname}`;
  }
}
