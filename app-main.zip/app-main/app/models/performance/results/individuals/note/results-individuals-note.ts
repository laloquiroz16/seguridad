import { Exclude, Expose, Type } from "class-transformer";
import { NoteAuthor } from "@models/performance/results";

export interface INoteLabel {
  id?: number;
  label: string;
  token?: string;
}

export interface ISettings {
  is_visible: boolean;
  selector_title: string;
  labels: INoteLabel[];
}

export class ResultsIndividualsNote {
  id: number;
  title: string;
  description: string;
  editable: boolean;
  label_id: number;
  visible_labels: boolean;
  settings: ISettings;
  note_label: INoteLabel;
  appeal_status: any;

  @Expose({ name: "private" })
  isPrivate: boolean;

  @Expose({ name: "updated_at" })
  updatedAt: string;

  @Expose({ name: "finalize_feedback_message" })
  finalizeFeedbackMessage: boolean;

  @Type(() => NoteAuthor)
  author: NoteAuthor;

  @Exclude({ toPlainOnly: true })
  editMode: boolean;

  @Exclude({ toPlainOnly: true })
  deleteMode: boolean;
}
