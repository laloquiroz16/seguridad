import { Exclude, Type } from "class-transformer";
import { ResultCategory } from "@models/performance/results";
import { ResultBasic } from "@models/performance/results/result-basic";

export class ResultCompetenceSummary extends ResultBasic {
  @Type(() => ResultCategory)
  categories: ResultCategory[];

  @Exclude({ toPlainOnly: true })
  open?: boolean;
}
