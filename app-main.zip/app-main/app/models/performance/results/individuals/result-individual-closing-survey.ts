import { SurveyStatus } from "@models/performance/survey/survey-status";

export class ResultIndividualClosingSurvey {
  status: number;
  date: string;
  hour: string;

  getColor(): string {
    return this.isFinished() ? "#009245" : "#808080";
  }

  getStatusClosingSurveyTranslate(): string {
    const status = this.isFinished() ? "finished" : "notFinished";
    return `performance.feedback.competences.summary.closingSurvey.${status}`;
  }

  isFinished(): boolean {
    return this.status === SurveyStatus.Finished;
  }
}
