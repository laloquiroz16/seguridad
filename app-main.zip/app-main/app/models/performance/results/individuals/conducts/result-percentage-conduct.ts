import { ResultBasic } from "@models/performance/results/result-basic";
import { Expose, Type } from "class-transformer";
import { CommentPercentageConduct } from "@models/performance/results";

export class ResultPercentageConduct extends ResultBasic {
  @Expose({ name: "category_name" })
  categoryName: string;
  @Type(() => CommentPercentageConduct)
  comments: CommentPercentageConduct[];
}
