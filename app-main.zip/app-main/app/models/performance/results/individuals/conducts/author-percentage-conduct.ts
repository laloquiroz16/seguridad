export class AuthorPercentageConduct {
  id: number;
  name: string;
  avatar: string;
}
