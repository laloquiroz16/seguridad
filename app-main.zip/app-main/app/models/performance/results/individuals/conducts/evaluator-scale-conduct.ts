export class EvaluatorScaleConduct {
  id: number;
  name: string;
  avatar: string;
  comment: string;
}
