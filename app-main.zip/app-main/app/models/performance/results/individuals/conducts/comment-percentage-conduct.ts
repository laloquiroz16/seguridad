import { Expose, Type } from "class-transformer";
import { AuthorPercentageConduct } from "@models/performance/results";

export class CommentPercentageConduct {
  id: number;
  comment: string;
  @Expose({ name: "updated_at" })
  updatedAt: string;
  @Type(() => AuthorPercentageConduct)
  author: AuthorPercentageConduct;
}
