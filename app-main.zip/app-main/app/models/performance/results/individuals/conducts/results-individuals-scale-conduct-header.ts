import { Exclude } from "class-transformer";
import { ColorService } from "@base/services";

export class ResultsIndividualsScaleConductHeader {
  label: string;
  color: string;
  order: number;

  @Exclude({ toPlainOnly: true })
  private readonly colorService: ColorService = new ColorService();

  getContrastColor(): string {
    if (!this.color) {
      return "black";
    }
    return this.colorService.ColorContrastYIQ(this.color);
  }

  getBorderColor(): string {
    if (!this.color) {
      return "#ddd";
    }
    return "white";
  }

  getColorCell(): any {
    const { r, g, b } = this.colorService.RGBFromHex("#091E42");
    return {
      "background-color": `rgba(${r},${g},${b},0.08)`,
      border: `solid 1px rgba(${r},${g},${b},0.3)`
    };
  }
  getBGColor(): any {
    return { "background-color": `${this.color || "#5e6c84"}` };
  }
}
