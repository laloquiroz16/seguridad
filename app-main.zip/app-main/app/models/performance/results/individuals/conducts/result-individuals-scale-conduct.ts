import { LevelScaleConduct } from "@models/performance/results";
import { Type } from "class-transformer";

export class ResultsIndividualsScaleConduct {
  id: number;
  name: string;
  description;
  @Type(() => LevelScaleConduct)
  levels: LevelScaleConduct[];
}
