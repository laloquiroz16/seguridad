import { Expose, Type } from "class-transformer";
import { EvaluatorScaleConduct } from "@models/performance/results";

export class ContentScaleConduct {
  id: number;
  category: string;
  @Expose({ name: "is_grouped" })
  isGrouped: boolean;
  @Type(() => EvaluatorScaleConduct)
  evaluators: EvaluatorScaleConduct[];
}
