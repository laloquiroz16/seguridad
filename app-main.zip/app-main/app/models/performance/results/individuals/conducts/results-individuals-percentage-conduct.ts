import { ResultPercentageConduct } from "@models/performance/results";
import { Type } from "class-transformer";

export class ResultsIndividualsPercentageConduct {
  id: number;
  name: string;
  @Type(() => ResultPercentageConduct)
  results: ResultPercentageConduct[];
}
