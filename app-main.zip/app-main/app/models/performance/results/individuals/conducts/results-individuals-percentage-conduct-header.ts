import { Expose } from "class-transformer";

export class ResultsIndividualsPercentageConductHeader {
  id: number;
  name: string;
  @Expose({ name: "category_name" })
  categoryName: string;
  @Expose({ name: "is_grouped" })
  isGrouped: boolean;
}
