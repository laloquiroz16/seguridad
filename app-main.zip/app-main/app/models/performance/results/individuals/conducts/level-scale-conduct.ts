import { ContentScaleConduct } from "@models/performance/results";
import { Type } from "class-transformer";

export class LevelScaleConduct {
  id: number;
  description: string;
  order: number;
  isOpen: boolean = false;
  @Type(() => ContentScaleConduct)
  contents: ContentScaleConduct[];
}
