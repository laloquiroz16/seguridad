export enum SectionIdentifierType {
  ActionPlan = "action_plan",
  Averages = "averages",
  Biography = "biography",
  CalibrationComment = "calibration_comment",
  Competence = "competence",
  Curriculum = "curriculum",
  Form = "form",
  Goal = "goal",
  GraphicSpider = "graphic_spider",
  Note = "note",
  PersonalInformation = "personal_information",
  Qualitative = "qualitative",
  StrengthsOpportunity = "strengths_opportunity",
  Instructions = "instructions",
  SummaryCompetence = "summary_competence",
  AssessableNewGoals = "assessable_new_goals"
}
