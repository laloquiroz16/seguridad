export enum ResultType {
  EvaluationDomain = "evaluation_domain",
  EvaluationCompetenceGroup = "evaluation_competencegroup",
  CategoryCompetenceGroup = "category_competencegroup",
  SelfAssessmentCompetenceGroup = "autoevaluation_competencegroup",
  SelfAssessment = "autoevaluation",
  CompetencesAverage = "evaluation_competences"
}
