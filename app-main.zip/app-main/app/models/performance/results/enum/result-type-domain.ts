export enum ResultTypeDomain {
  Average = "average",
  Matrix = "matrix_position"
}
