import { Expose } from "class-transformer";
import ICollaboratorInfo from "@models/performance/coordination/collaborator-info";

export class CoordinationCollaboratorInformation implements ICollaboratorInfo {
  id: number;
  name: string;
  token: string;
  position: string;
  avatar: string;
  area: string;
  meeting: any;
  active: boolean;

  @Expose({ name: "assessment_progress" })
  assessmentProgress: number;

  @Expose({ name: "assessment_amount" })
  assessmentAmount: number;

  @Expose({ name: "assessments_completed" })
  assessmentsCompleted: boolean;

  coordinated: boolean;
}
