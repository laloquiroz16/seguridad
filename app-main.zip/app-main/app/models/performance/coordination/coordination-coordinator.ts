import CoordinationStatus from "@models/performance/coordination/coordination-status";
import { Expose } from "class-transformer";
import ICollaboratorInfo from "@models/performance/coordination/collaborator-info";

class CoordinationCoordinator implements ICollaboratorInfo {
  area: string;
  avatar: string;
  id: number;
  identifier: string;
  name: string;
  position: string;
  status: CoordinationStatus = 0;
  token: string;

  @Expose({ name: "assessment_count" })
  assessmentCount: number;
  @Expose({ name: "access_to_area" })
  accessToArea: number;
}
export default CoordinationCoordinator;
