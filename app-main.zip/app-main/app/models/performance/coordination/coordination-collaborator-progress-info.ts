import ICollaboratorInfo from "@models/common/collaborator-info";

export class CoordinationCollaboratorProgress {
  id: number;
  status: number;
  category: string;
  evaluator: ICollaboratorInfo;
}
