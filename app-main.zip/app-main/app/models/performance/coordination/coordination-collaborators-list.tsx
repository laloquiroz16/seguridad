import { Type } from "class-transformer";
import { CoordinationCollaboratorInformation } from "./coordination-collaborator-information";

export class CoordinationCollaboratorList {
  @Type(() => CoordinationCollaboratorInformation)
  collaborators: CoordinationCollaboratorInformation[] = [];

  total: number = 0;
}
