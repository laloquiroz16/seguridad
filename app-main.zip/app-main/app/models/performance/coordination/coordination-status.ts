enum CoordinationStatus {
  Pending,
  InProgress,
  Finished
}
export default CoordinationStatus;
