import { IPerformanceMonitoringSubTab } from "@models/performance/monitoring/PerformanceMonitoringSubTab";
export interface INewMonitoringContainerState {
  tableData: {
    data: any;
    meta: {
      finished: number;
      inProgress: number;
      toStart: number;
      total: number;
      customTableTotal?: number;
      states?: any[]; // used for goals monitoring and any monitoring that has more than 3 states
    };
  };
  selectedSubTab: IPerformanceMonitoringSubTab;
  progressBarData: {
    finished: number;
    inProgress: number;
    toStart: number;
    total: number;
    progressTranslations: any;
    progressBarColors: any;
  };
  currentPage: number;
  perPage: number;
  searchTerm: string;
  currentSortedHeader: any;
  isLoading?: boolean;
  isReminderModalVisible?: boolean;
  isResetModalVisible?: boolean;
  isChangeStatusModalVisible?: boolean;
  isDeleteModalVisible?: boolean;
  isDeleteModalOnReplaceEvaluatorVisible?: boolean;
  isReplaceEvaluatorModalVisible?: boolean;
  selectedRows?: any[];
  unselectedRows?: any[];
  allRowsSelected?: boolean;
  triggerReload?: boolean;
  isRowAction?: boolean;
}
