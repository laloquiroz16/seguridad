export interface IPerformanceMonitoringEndpointParams {
  processId: number;
  areaId: number;
  currentPage: number;
  perPage: number;
  filters?: any;
  resetChecks?: boolean;
  searchTerm: string;
  sortedHeader: any;
  selectedCategory?: any;
  cancelToken?: any;
  subTabId?: string;
}
