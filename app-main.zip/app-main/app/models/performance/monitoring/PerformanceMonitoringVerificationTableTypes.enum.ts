export enum PerformanceMonitoringVerificationTableTypes {
  VerificationVerifiers = "verifiers",
  VerificationEvaluators = "verification_evaluators",
  VerificationVerifiersByAreas = "verifiers_by_areas",
  VerificationEvaluatorsByAreas = "evaluators_by_areas",
  VerificationChangeRequests = "change_requests"
}
