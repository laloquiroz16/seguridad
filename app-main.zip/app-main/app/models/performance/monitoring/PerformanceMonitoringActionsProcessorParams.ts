export interface IPerformanceMonitoringActionsProcessorParams {
  tabId: string;
  subTabId: string;
  processId: number;
  areaId: number;
  checkedRowsToApplyActions: any[];
  uncheckedRowsToApplyActions?: any[];
  allRowsChecked: boolean;
  filters: any;
  searchTerm: string;
  managerHasAdminAccess?: boolean;
  messageFromModal?: {
    messageFromModal: {
      subject: string;
      message: string;
    };
  };
}

export interface IEvaluationsProcessorParams
  extends IPerformanceMonitoringActionsProcessorParams {
  isResetModalCheckboxChecked: boolean;
  isResetVerificationChecked: boolean;
}

export interface IFeedbackProcessorParams
  extends IPerformanceMonitoringActionsProcessorParams {
  resetActionPlans: boolean;
  resetFeedbackEvaluable: boolean;
}

export interface IGoalsProcessorParams
  extends IPerformanceMonitoringActionsProcessorParams {
  resetActionPlans: boolean;
  goalStatus: string;
}
