export enum PerformanceMonitoringEvaluationTableTypes {
  EvaluationAreas = "areas",
  EvaluationEvaluators = "evaluators",
  EvaluationEvaluations = "evaluations",
  EvaluationCollaborators = "collaborators",
  EvaluationReplaceEvaluator = "replace_evaluator"
}
