export enum PerformanceMonitoringCalibrationTableTypes {
  CalibrationAreaCalibrateds = "area_calibrated",
  CalibrationAreaCalibrators = "area_calibrators",
  CalibrationAreas = "areas",
  CalibrationGroupCalibrateds = "group_calibrated",
  CalibrationGroupCalibrators = "group_calibrators",
  CalibrationGroups = "groups"
}

export enum PerformanceMonitoringNewCalibrationTableTypes {
  CalibrationAreasGroups = "groups",
  CalibrationCalibrators = "calibration_calibrators",
  CalibrationCalibrated = "calibration_calibrated"
}

export enum progressTranslationsStatuses {
  toStart = "selectAreasAndFilters.filter.not_calibrated",
  inProgress = "selectAreasAndFilters.filter.calibrated",
  finished = "selectAreasAndFilters.filter.accepted",
  total = "performance.newMonitoring.content.calibration.progressBar.total"
}

export enum calibrationProgressBarColors {
  toStart = "#aaa9a9",
  inProgress = "#00ace3",
  finished = "#36b37e"
}
