export enum PerformanceMonitoringValidationTableTypes {
  ValidationHierarchicalValidators = "hierarchical_validators",
  ValidationMatricialValidators = "matrix_validators",
  ValidationHierarchicalValidateds = "hierarchical_validateds",
  ValidationMatricialValidateds = "matrix_validateds"
}
