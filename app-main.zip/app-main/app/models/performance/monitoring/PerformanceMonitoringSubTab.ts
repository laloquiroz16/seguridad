import { IProgressTranslations } from "@src/performance/monitoring/services/PerformanceMonitoringCommonService";
import { INewMonitoringContainerState } from "./new-monitoring-contaner-state";
import { IPerformanceMonitoringEndpointParams } from "@models/performance/monitoring/PerformanceMonitoringEndpointParams";

type ChartTypes = "pieChart" | "flowChart"; // can be extended to any types of charts
export interface IPerformanceMonitoringSubTab {
  id: string;
  title: string;
  tooltip: string;
  visible: boolean;
  active: boolean;
  showMetadata?: boolean;
  progressTranslations: IProgressTranslations | {}; // if not needed because not using default progress bar and panels, send and empty object
  endpointToFetch: (
    endpointParams: IPerformanceMonitoringEndpointParams
  ) => Promise<any>;
  // set custom progress bar and panel colors for the meta section, if ignored the components
  // fall back to default colors (red, yellow and green for to start, in progress and finished
  // respectively)
  progressBarColors?: {
    toStart: string;
    inProgress: string;
    finished: string;
  };
  //use order to sort Each tab according to config
  order?: number;
  // Use customTableKey when the id of the rows in one of the tables is not the default
  // id property
  customTableKey?: string;
  // Use customMetaKeys when the keys from the meta object that comes from the
  // backend don't match the default keys that the frontend needs
  customMetaKeys?: {
    finished: string;
    inProgress: string;
    pending: string;
    // This value modifies the total displayed at the top left of the table
    // (grey oval), pass in the KEY that retrieves that number from the object
    customTableTotal?: string;
  };
  // if chart configuration isn't declared, then the monitoring will always use
  // the global progress bar and statistic panels
  chartConfiguration?: {
    type: ChartTypes; // can be extended to support any kinds of charts
    chartDataFn: (
      t: any, // translation object
      state: INewMonitoringContainerState, // tab context provider state
      externalStates?: any[] // this is used if you need to pass states information from an external endpoint, new goals monitoring uses this
    ) => void; // pass a reference to a function that must return an array of the statuses that the chart has to support
  };
}
