export enum PerformanceMonitoringClosingSurveyTypes {
  ClosingSurveyFeedback = "closing_survey_feedbacks",
  ClosingSurveyGoal = "closing_survey_goals"
}
