export enum PerformanceMonitoringCoordinationTableTypes {
  CoordinationCoordinateds = "coordinateds",
  CoordinationCoordinators = "coordinators",
  CoordinationAreas = "coordination_areas"
}
