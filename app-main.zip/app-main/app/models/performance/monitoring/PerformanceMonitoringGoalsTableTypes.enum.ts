export enum PerformanceMonitoringGoalsTableTypes {
  GoalsCollaborators = "goal_collaborators",
  GoalsEvaluators = "goal_evaluators",
  GoalsAreas = "goal_areas"
}
