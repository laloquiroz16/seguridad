export interface IChangeStatusModalStatusObj {
  id: number | string;
  value: any;
  label: string;
}

interface IChangeStatusModalTranslationKeys {
  title: string;
  dropdownLabel: string;
  submitButtonLabel: string;
  descriptionBeforeAmount?: string;
  descriptionAfterAmount?: string;
  additionalInfo?: string;
}

export interface IChangeStatusModalConfiguration {
  tabId: string;
  subTabId: string;
  changeStatusEndpointFunction: Function; // assign a *reference* to and endpoint function here
  statuses: IChangeStatusModalStatusObj[]; // structure that the change status modal uses to display the statuses dropdown
  modalTranslationKeys: IChangeStatusModalTranslationKeys;
  warningMessageKey?: string;
  customKey?: string;
}
