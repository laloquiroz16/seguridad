export interface IPerformanceMonitoringNavbarTab {
  id: string;
  title: string;
  visible: boolean;
  active: boolean;
  firstSubTab: {
    active: boolean;
    identifier: string;
    order: number;
  };
  subTabs?: [any];
  order: number;
}
