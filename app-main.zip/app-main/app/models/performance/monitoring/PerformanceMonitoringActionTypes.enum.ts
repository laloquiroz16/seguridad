export enum PerformanceMonitoringActionTypes {
  Reset = "RESET",
  SendReminder = "SEND_REMINDER",
  Download = "DOWNLOAD",
  ChangeStatus = "CHANGE_STATUS",
  Delete = "DELETE",
  ReplaceEvaluator = "CHANGE_EVALUATOR"
}
