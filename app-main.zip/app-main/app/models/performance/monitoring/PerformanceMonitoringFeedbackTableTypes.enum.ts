export enum PerformanceMonitoringFeedbackTableTypes {
  FeedbackEvaluators = "feedback_evaluators",
  FeedbackCollaborators = "feedback_collaborators",
  FeedbackAreas = "feedback_areas"
}
