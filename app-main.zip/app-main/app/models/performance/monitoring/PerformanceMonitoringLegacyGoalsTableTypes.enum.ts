export enum PerformanceMonitoringLegacyGoalsTableTypes {
  LegacyGoalEvaluations = "legacy_goal_evaluations"
}
