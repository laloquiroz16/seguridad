// it's important that the VALUES (right side of the enums) are in snake_case for API
// compatibility, this also applies to all subtab enums, the files are:

// VerificationTableTypes.ts
// ValidationTableTypes.ts
// EvaluationTableTypes.ts
// FeedbackTableTypes.ts
// CoordinationTableTypes.ts
// CalibrationTableTypes.ts
// LegacyGoalTableTypes.ts
// GoalTableTypes.ts
// ClosingSurveyTypes.ts

export enum PerformanceMonitoringTypes {
  Calibration = "calibration",
  NewCalibration = "new_calibration",
  Evaluation = "evaluation",
  Validation = "validation",
  Coordination = "coordination",
  ClosingSurvey = "closing_survey",
  Verification = "verification",
  Feedback = "feedback",
  Goal = "goal",
  LegacyGoal = "legacy_goal"
}
