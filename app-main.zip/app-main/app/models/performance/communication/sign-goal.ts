import { Exclude, Expose } from "class-transformer";

export class SignGoal {
  id?: number;

  @Expose({ name: "send_notification" })
  sendNotification: boolean;

  @Expose({ name: "body" })
  body: any;

  @Expose({ name: "enterprise_process_id" })
  @Exclude({ toPlainOnly: true })
  enterpriseProcessId: number;
}
