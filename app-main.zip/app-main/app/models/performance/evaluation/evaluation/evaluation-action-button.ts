export interface IEvaluationActionButtonType {
  id: string;
  title: string;
  classList: string;
  isDisabled: boolean;
  isVisible: boolean;
  URLToRedirectTo?: string; // use if it's a link button
  actionToExecute?: any; // use to call an arbitrary function of your choosing
  disabledTooltip?: string;
  evaluatorId?: number;
  collaboratorId?: number;
  assessmentId?: number;
  processId?: number;
}

export default IEvaluationActionButtonType;
