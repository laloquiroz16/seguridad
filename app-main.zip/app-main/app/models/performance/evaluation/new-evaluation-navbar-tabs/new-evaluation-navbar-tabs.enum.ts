export enum NewEvaluationNavbarTabs {
  EvaluablesList = "collaborators",
  Summary = "summary",
  Distribution = "distribution"
}
