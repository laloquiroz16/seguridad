import { Expose, Type } from "class-transformer";
import { Author } from "./author";

export class Comment {
  id: number;
  comment: string = "";
  editable: number = 1;

  @Expose({ name: "author_category_name" })
  categoryName: string = "";

  @Expose({ name: "created_at" })
  createdAt: string = "";

  @Expose({ name: "updated_at" })
  updatedAt: string = "";

  @Expose({ name: "author" })
  @Type(() => Author)
  author: Author;
}
