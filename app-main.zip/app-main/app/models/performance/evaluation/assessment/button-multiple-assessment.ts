import { Expose } from "class-transformer";

export class ButtonMultipleAssessment {
  id: number;
  status: number;

  @Expose({ name: "is_enabled" })
  isEnabled: boolean;

  @Expose({ name: "is_visible" })
  isVisible: boolean;

  getTranslate(): string {
    return `performance.multipleAssessment.do.status${this.status}`;
  }
  getBtnColor(): string {
    let color;
    switch (this.status) {
      case 0: {
        color = "button-green";
        break;
      }
      case 1: {
        color = "button-orange";
        break;
      }
      case 2: {
        color = "button-blue";
        break;
      }
      default: {
        color = "";
      }
    }
    return color;
  }
}
