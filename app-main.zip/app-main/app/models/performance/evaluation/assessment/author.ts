import { Expose } from "class-transformer";

export class Author {
  id: number;
  name: string = "";
  token: string;

  @Expose({ name: "lastname" })
  lastName: string = "";

  @Expose({ name: "avatar_url" })
  avatarUrl: string = "";

  fullName() {
    return `${this.name} ${this.lastName}`;
  }
}
