export enum CompetenceType {
  ANCCond = "anc_cond",
  Star = "star",
  Likert = "likert",
  Dropdown = "dropdown",
  Slider = "slider"
}
