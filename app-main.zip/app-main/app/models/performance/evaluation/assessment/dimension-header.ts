import { Expose } from "class-transformer";

export class DimensionHeader {
  id: number;
  name: string;
  sort?: number = 2;

  @Expose({ name: "result_type_selected" })
  resultTypeSelected: string;

  updateSort(): void {
    this.sort = this.sort === 2 ? 0 : this.sort + 1;
  }

  getClassSort(): string {
    switch (this.sort) {
      case 0: {
        return "st-sort-descent";
      }
      case 1: {
        return "st-sort-ascent";
      }
      default: {
        return "";
      }
    }
  }
}
