import { Expose } from "class-transformer";

export class UserResumeSuccessor {
  id: number;

  @Expose({ name: "have_successor" })
  hasSuccessor: boolean;
}
