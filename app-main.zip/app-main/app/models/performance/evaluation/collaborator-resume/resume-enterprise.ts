import { Expose } from "class-transformer";

export class ResumeEnterprise {
  id: number;

  @Expose({ name: "name" })
  name: string = "";
}
