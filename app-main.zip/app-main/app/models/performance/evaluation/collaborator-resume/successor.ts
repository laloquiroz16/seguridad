import { Exclude, Expose } from "class-transformer";

export class Successor {
  name: string;
  lastname: string;
  email: string;
  area: string;

  @Exclude({ toPlainOnly: true })
  id?: number;

  @Expose({ name: "enterprise_position_name" })
  @Exclude({ toPlainOnly: true })
  position: string;

  @Expose({ name: "user_avatar" })
  @Exclude({ toPlainOnly: true })
  avatarUrl: string;

  @Exclude({ toPlainOnly: true })
  identifier?: number;

  formattedName() {
    return `${this.name} ${this.lastname} - ${this.email}`;
  }

  completedName() {
    return `${this.name} ${this.lastname}`;
  }
}
