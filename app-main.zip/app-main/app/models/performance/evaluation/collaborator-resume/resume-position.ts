import { Expose, Exclude } from "class-transformer";

export class ResumePosition {
  id: number;

  @Expose({ name: "name" })
  name: string = "";

  @Exclude({ toPlainOnly: true })
  @Expose({ name: "slug" })
  slug: string = "";

  @Expose({ name: "enterprise_id" })
  enterpriseId: number;
}
