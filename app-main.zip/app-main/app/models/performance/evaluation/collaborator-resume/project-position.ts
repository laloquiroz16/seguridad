import { Expose, Exclude, Type } from "class-transformer";
import { ResumeEnterprise } from "./resume-enterprise";
import { EnterpriseBusiness } from "./enterprise-busisness";
import { ResumePosition } from "./resume-position";
import { Country } from "./country";
import { Creator } from "./creator";

export class ProjectPosition {
  id: number;
  description: string = "";
  area: string = "";

  @Expose({ name: "user_id" })
  userId: number;

  @Expose({ name: "creator" })
  @Exclude({ toPlainOnly: true })
  @Type(() => Creator)
  creator: Creator = new Creator();

  @Expose({ name: "time_lapse" })
  timeLapse: number;

  @Exclude({ toPlainOnly: true })
  @Expose({ name: "resume_position" })
  @Type(() => ResumePosition)
  resumePosition: ResumePosition;

  @Exclude({ toPlainOnly: true })
  @Expose({ name: "resume_enterprise" })
  @Type(() => ResumeEnterprise)
  resumeEnterprise: ResumeEnterprise;

  @Exclude({ toPlainOnly: true })
  @Expose({ name: "enterprise_business" })
  @Type(() => EnterpriseBusiness)
  enterpriseBusiness: EnterpriseBusiness;

  @Exclude({ toPlainOnly: true })
  @Type(() => Country)
  country: Country;

  @Expose({ name: "country_id" })
  countryId() {
    if (this.country) {
      return this.country.id;
    }
  }

  @Expose({ name: "resume_position_id" })
  resumePositionId() {
    if (this.resumePosition) {
      return this.resumePosition.id;
    }
  }

  @Expose({
    name: "enterprise_business_id",
    groups: ["asignEnterpriseBusiness"]
  })
  enterpriseBusinessId() {
    if (this.enterpriseBusiness) {
      return this.enterpriseBusiness.id;
    }
  }

  @Expose({
    name: "enterprise_business_attributes",
    groups: ["createEnterpriseBusiness"]
  })
  enterpriseBusinessAttributes() {
    if (this.enterpriseBusiness) {
      return this.enterpriseBusiness;
    }
  }

  @Expose({ name: "resume_enterprise_id" })
  resumeEnterpriseId() {
    if (this.resumeEnterprise) {
      return this.resumeEnterprise.id;
    }
  }

  busisnessGroups() {
    if (!this.enterpriseBusiness) {
      return [];
    }

    const { editable, id, enterpriseId } = this.enterpriseBusiness;

    if (!editable) {
      return [];
    }

    if (this.enterpriseBusiness && !enterpriseId && id !== -1) {
      return ["asignEnterpriseBusiness"];
    } else {
      return ["createEnterpriseBusiness"];
    }
  }
}
