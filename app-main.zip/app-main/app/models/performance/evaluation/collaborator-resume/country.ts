import { Expose } from "class-transformer";

export class Country {
  id: number;

  @Expose({ name: "name" })
  name: string = "";

  @Expose({ name: "isoCode" })
  isoCode: string = "";

  @Expose({ name: "language" })
  language: string = "";
}
