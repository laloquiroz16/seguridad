export enum SectionIdentifer {
  ProjectPosition = "projectPosition",
  Succession = "succession",
  ResumeInterests = "resume_interests"
}
