export enum UserAction {
  Add = "Agregar",
  Edit = "Editar"
}
