export enum SuccessorType {
  internal = "internal",
  external = "external",
  evaluable = 1,
  evaluator = 2,
  global = 3
}
