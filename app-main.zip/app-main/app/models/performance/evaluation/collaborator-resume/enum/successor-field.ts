export enum SuccessorField {
  haveSuccessor = "have_successor",
  typeSuccessor = "type_successor"
}
