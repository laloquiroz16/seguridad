import { Expose, Type, Exclude } from "class-transformer";
import { SuccessorType } from "./enum/successor-type";
import { Successor } from "./successor";
import { UserResumeSuccessor } from "./user-resume-successor";
import { Creator } from "./creator";

export class ResumeSuccessor {
  id: number;

  @Expose({ name: "succession_time" })
  successionTime: number;

  @Expose({ name: "have_successor" })
  @Exclude({ toPlainOnly: true })
  hasSuccessor: boolean;

  @Expose({ name: "approved_by_calibrator", groups: ["calibratorOwner"] })
  approvedByCalibrator: boolean;

  @Expose({ name: "type_successor" })
  typeSuccessor: string = SuccessorType.internal;

  @Expose({ name: "creator" })
  @Exclude({ toPlainOnly: true })
  @Type(() => Creator)
  creator: Creator = new Creator();

  @Expose({ name: "successor" })
  @Exclude({ toPlainOnly: true })
  @Type(() => Successor)
  successor: Successor = new Successor();

  @Expose({ name: "user" })
  @Exclude({ toPlainOnly: true })
  @Type(() => UserResumeSuccessor)
  user: UserResumeSuccessor = new UserResumeSuccessor();

  @Expose({ name: "successor_id", groups: ["internal"] })
  successorId() {
    return this.successor.id;
  }

  @Expose({ name: "external_successor_attributes", groups: ["external"] })
  externalSuccessorAttr() {
    return this.successor;
  }

  @Expose({ name: "calibrated" })
  calibrated: boolean;

  formattedName() {
    const { name, lastname, email } = this.successor;
    return `${name} ${lastname} - ${email}`;
  }

  isInternal() {
    return SuccessorType.internal === this.typeSuccessor;
  }

  typeSuccessorGroup(someGroup?) {
    const groups = [];
    const successorType =
      this.typeSuccessor == SuccessorType.internal
        ? SuccessorType.internal
        : SuccessorType.external;

    groups.push(successorType);

    if (someGroup.calibratorOwner) {
      groups.push(someGroup.calibratorOwner);
    }

    return groups;
  }

  typeSuccessorTranslate() {
    return `performance.assessment.resume.succession.typeSuccessor.${this.typeSuccessor}`;
  }
}
