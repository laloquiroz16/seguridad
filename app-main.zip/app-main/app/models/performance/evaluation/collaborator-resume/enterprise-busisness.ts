import { Expose } from "class-transformer";

export class EnterpriseBusiness {
  id: number;
  editable: boolean;

  @Expose({ name: "name" })
  name: string = "";

  @Expose({ name: "enterprise_id" })
  enterpriseId: number;
}
