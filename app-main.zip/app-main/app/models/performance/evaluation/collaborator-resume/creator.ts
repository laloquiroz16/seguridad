import { Expose, Exclude } from "class-transformer";

export class Creator {
  id: number;
  name: string = "";
  token: string = "";
  identifier: string = "";

  @Expose({ name: "lastname" })
  lastName: string = "";

  @Expose({ name: "avatar_url" })
  avatarUrl: string = "";

  @Expose({ name: "enterprise_position_name" })
  @Exclude({ toPlainOnly: true })
  enterprisePositionName: string = "";

  fullName() {
    return `${this.name} ${this.lastName}`;
  }
}
