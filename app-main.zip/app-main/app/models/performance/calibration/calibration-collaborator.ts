import { Expose } from "class-transformer";
import ICollaboratorInfo from "@models/performance/coordination/collaborator-info";
import { UserCalibrationStatus } from "@models/performance";

class CalibrationCollaborator implements ICollaboratorInfo {
  area: string;
  avatar: string;
  id: number;
  calibrator_id: number;
  identifier: string;
  name: string;
  position: string;
  status: UserCalibrationStatus = 0;
  @Expose({ name: "calibrate_more_than_once" })
  calibrateMoreThanOnce: boolean;
}

export default CalibrationCollaborator;
