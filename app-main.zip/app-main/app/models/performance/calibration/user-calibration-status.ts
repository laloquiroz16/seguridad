export enum UserCalibrationStatus {
  NotCalibrated = 0,
  Calibrated = 1,
  Accepted = 2
}
