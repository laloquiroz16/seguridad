import { Expose, Exclude } from "class-transformer";
import { MinValidation } from "@models/performance/configuration/action-plan/enum/min-validation";

export class ConfigurationActionPlan {
  @Exclude({ toPlainOnly: true })
  id?: number;
  @Expose({ name: "action_plan_min_validation" })
  actionPlanMinValidation: MinValidation;
  @Expose({ name: "evaluator_max_action_plans" })
  evaluatorMaxActionPlans: number;
  @Expose({ name: "evaluator_min_action_plans" })
  evaluatorMinActionPlans: number;
  @Expose({ name: "evaluable_min_action_plans" })
  evaluableMinActionPlans: number;
  @Expose({ name: "global_min_action_plans" })
  globalMinActionPlans: number;
  @Expose({ name: "global_max_action_plans" })
  globalMaxActionPlans: number;
  @Expose({ name: "show_results_without_action_plans" })
  showResultsWithoutActionPlans: boolean;
}
