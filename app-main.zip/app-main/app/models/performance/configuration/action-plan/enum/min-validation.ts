export enum MinValidation {
  Evaluator = "evaluator",
  AllAuthors = "all_authors"
}
