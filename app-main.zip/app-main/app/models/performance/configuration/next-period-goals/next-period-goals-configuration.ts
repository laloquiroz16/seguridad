import { Exclude, Expose } from "class-transformer";

export class NextPeriodGoalsConfiguration {
  @Exclude({ toPlainOnly: true })
  id?: number;
  @Expose({ name: "enable_objective_goal" })
  enableObjectiveGoal: boolean;
  @Expose({ name: "visible_goal_comment" })
  visibleGoalComment: boolean;
  @Expose({ name: "hide_objectives" })
  hideObjectives: boolean;
  @Expose({ name: "minimum_goals" })
  minimumGoals: number;
}
