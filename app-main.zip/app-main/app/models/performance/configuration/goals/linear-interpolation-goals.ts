export interface ILinearInterpolationGoalScaleAngular {
  id: number;
  title: string;
  code: string;
  ranges: Array<{ order: string; min: number; max: number }>;
}

export interface ILinearInterpolationGoalAngular {
  id: number;
  positive_slope: boolean;
  ranges: Array<{ order: string; left: number; right: number }>;
  linear_interpolation_goal_scales_id: number;
  evaluation_user_dimensions_id: number;
}
