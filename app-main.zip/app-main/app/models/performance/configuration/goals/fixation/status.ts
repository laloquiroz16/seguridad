import { Expose } from "class-transformer";

export class StatusFixation {
  id: number | null;
  color: string;
  token: string | null;
  status: string;

  @Expose({ name: "translated_name" })
  translatedName: string;

  @Expose({ name: "status_identifier" })
  statusIdentifier: string;

  @Expose({ name: "name_translate" })
  nameTranslate: string;
}
