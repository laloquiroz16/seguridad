import { Expose } from "class-transformer";

export class GoalSettingConfiguration {
  id: number;

  @Expose({ name: "notify_evaluator_on_save_goals" })
  notifyEvaluatorOnSaveGoals: boolean;

  @Expose({ name: "notify_collaborator_on_save_goals" })
  notifyCollaboratorOnSaveGoals: boolean;
}
