import { Expose } from "class-transformer";

export class KpiGoalsType {
  id: number;
  name: string = "";
  code: string = "";

  @Expose({ name: "enterprise_process_id" })
  enterpriseProcessId: number;
}
