export class ConfigurationReviewQuery {
  id: string;
  title: string;
  description: string;
  status: string;
  data: string;
  pendingRequest: boolean;
  link: string;
  translated_key: string;
}
