import { Expose } from "class-transformer";
export class CoordinationStage {
  id: number;

  @Expose({ name: "enable_coordination_stage" })
  enableCoordinationStage: boolean;

  @Expose({ name: "required_for_calibration" })
  requiredForCalibration: boolean;

  @Expose({ name: "enable_interviews" })
  enableInterviews: boolean;

  @Expose({ name: "enable_create_commitment" })
  enableCreateCommitment: boolean;

  @Expose({ name: "enable_completion_message" })
  enableCompletionMessage: boolean;

  @Expose({ name: "mail_coordinator_after_completed_evaluation" })
  mailCoordinatorAfterCompletedEvaluation: boolean;

  @Expose({ name: "survey_id" })
  surveyId: number;
}
