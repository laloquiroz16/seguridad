import { Expose } from "class-transformer";

export class PreliminaryResult {
  id: number;
  name: string;
  @Expose({ name: "show_value" })
  showValue: boolean;
  @Expose({ name: "show_label" })
  showLabel: boolean;
  @Expose({ name: "show_graphic" })
  showGraphic: boolean;
  type: string;
}
