export enum GoalType {
  General = "general",
  SelfFixation = "self_fixation",
  Feedback = "feedback",
  SelfAssessment = "self_assessment"
}
