export enum TypeAttribute {
  General = "general",
  Goal = "goal",
  Competence = "competence",
  Category = "category",
  SelfAssessment = "self_assessment",
  Conduct = "conducts",
  SelfAssessmentCompetence = "self_assessment_competence",
  SelfAssessmentGoal = "self_assessment_goal",
  CategoryAverage = "category_average",
  Goals = "goals",
  CategoryGoals = "category_goals",
  SelfAssessmentGoals = "self_assessment_goals"
}
