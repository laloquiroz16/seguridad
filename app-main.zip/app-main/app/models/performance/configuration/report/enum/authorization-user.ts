export enum AuthorizationUser {
  Superadmin = "superadmin",
  Admin = "admin",
  Manager = "manager",
  Calibrator = "calibrator",
  Evaluator = "evaluator",
  Coordinator = "coordinator",
  Validator = "validator",
  Collaborator = "collaborator"
}
