export enum ConductTableType {
  Scale = "scales",
  Percentage = "percentage"
}
