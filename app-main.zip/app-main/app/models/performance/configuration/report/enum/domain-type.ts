export enum DomainType {
  General = "general",
  Default = "default",
  Other = "others"
}
