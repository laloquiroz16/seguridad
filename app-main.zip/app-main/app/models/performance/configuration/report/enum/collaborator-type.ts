export enum CollaboratorType {
  Evaluator = "evaluator",
  Collaborator = "collaborator",
  Calibrator = "calibrator"
}
