import { Expose } from "class-transformer";
import { CollaboratorType } from "@models/performance/configuration/report/enum/collaborator-type";

export class ReportCollaborator {
  [key: string]: any;

  id?: number;

  @Expose({ name: "show_collaborator" })
  showCollaborator: boolean = false;

  @Expose({ name: "show_position" })
  showPosition: boolean = false;

  @Expose({ name: "show_rut" })
  showRut: boolean = false;

  @Expose({ name: "show_area" })
  showArea: boolean = false;

  @Expose({ name: "show_avatar" })
  showAvatar: boolean = false;

  @Expose({ name: "type_collaborator" })
  typeCollaborator: CollaboratorType;
}
