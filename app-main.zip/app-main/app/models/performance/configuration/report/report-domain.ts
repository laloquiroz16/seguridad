import { Expose, Type } from "class-transformer";
import {
  DomainType,
  ReportAverageAttribute
} from "@models/performance/configuration";

export class ReportDomain {
  id: number;

  @Expose({ name: "show_domain" })
  showDomain: boolean;

  @Expose({ name: "domain_id" })
  domainId: number;

  name: string;

  @Expose({ name: "type_domain" })
  domainType: DomainType;

  @Expose({ name: "average_attributes_attributes" })
  @Type(() => ReportAverageAttribute)
  averageAttributes: ReportAverageAttribute[] = [];
}
