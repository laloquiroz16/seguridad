import { AuthorizationUser } from "./enum/authorization-user";
import { Exclude, Expose } from "class-transformer";

export class ReportAuthorization {
  @Exclude({ toPlainOnly: true })
  id?: number;
  @Expose({ name: "authorization_user" })
  authorizationUser: AuthorizationUser;
}
