import { Expose } from "class-transformer";

export class ReportFeedbackLetterConfiguration {
  id: number;

  @Expose({ name: "enabled" })
  enabled: boolean;
}
