import { Expose } from "class-transformer";
import { TypeAttribute } from "@models/performance/configuration";

export class ReportAverageAttribute {
  [key: string]: any;

  id?: number;

  @Expose({ name: "show_attribute" })
  showAttribute: boolean = false;

  @Expose({ name: "show_label" })
  showLabel: boolean = false;

  @Expose({ name: "show_value" })
  showValue: boolean = false;

  @Expose({ name: "show_graphic" })
  showGraphic: boolean = false;

  @Expose({ name: "show_comment" })
  showComment?: boolean = false;

  @Expose({ name: "type_attribute" })
  typeAttribute?: TypeAttribute;
}
