import { ReportAuthorization } from "./report-authorization";
import { ReportDomain } from "./report-domain";
import { Exclude, Expose, Type } from "class-transformer";
import { AuthorizationUser } from "@models/performance/configuration";

export class ReportConfiguration {
  id: number;
  description: string = "";
  name: string = "";

  @Expose({ name: "is_enable" })
  isEnable: boolean = true;

  @Expose({ name: "show_summary" })
  showSummary: boolean = false;

  @Expose({ name: "show_unit_domain" })
  showUnitDomain: boolean = false;

  @Expose({ name: "authorizations_attributes" })
  @Type(() => ReportAuthorization)
  authorizations: ReportAuthorization[] = [];

  @Expose({ name: "domains_attributes" })
  @Type(() => ReportDomain)
  domains: ReportDomain[] = [];

  @Exclude({ toPlainOnly: true })
  canCreateNewReport: boolean = true;

  @Exclude({ toPlainOnly: true })
  canGenerateReport: boolean = false;

  updateGenerateReport() {
    this.canCreateNewReport = false;
    this.canGenerateReport = true;
  }
  cantEnableFeedbackLetterButton() {
    const deniedAuthorizations = [
      AuthorizationUser.Validator,
      AuthorizationUser.Coordinator
    ];
    return this.authorizations.some(({ authorizationUser }) =>
      deniedAuthorizations.includes(authorizationUser)
    );
  }
  onlyConfigurationEvaluator() {
    const [{ authorizationUser }] = this.authorizations;
    return authorizationUser === AuthorizationUser.Evaluator;
  }
}
