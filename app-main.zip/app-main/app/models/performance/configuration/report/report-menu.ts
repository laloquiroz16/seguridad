export class ReportMenuConfiguration {
  id: number;
  order: number;
  identifier: string;
}
