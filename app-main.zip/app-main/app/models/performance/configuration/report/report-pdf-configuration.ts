import { Expose } from "class-transformer";

export class ReportPdfConfiguration {
  id: number;

  @Expose({ name: "enable_download" })
  enableDownload: boolean;

  @Expose({ name: "show_enterprise_information" })
  showEnterpriseInformation: boolean;

  @Expose({ name: "enable_legal_text" })
  enableLegalText: boolean;

  @Expose({ name: "text_legal" })
  textLegal: boolean;

  @Expose({ name: "enable_signature" })
  enableSignature: boolean;

  @Expose({ name: "show_pdf_evaluable" })
  showPdfEvaluable: boolean;

  @Expose({ name: "enable_download_summary" })
  enableDownloadSummary: boolean;

  @Expose({ name: "enable_curriculum_pdf_summary" })
  enableCurriculumPdfSummary: boolean;

  @Expose({ name: "enable_process_cronology" })
  enableProcessCronology: boolean;

  canDownload() {
    return (
      this.enableDownload || this.enableDownloadSummary || this.showPdfEvaluable
    );
  }
  canShowCurriculumInSummary() {
    return this.enableDownloadSummary;
  }
  isDisabled() {
    return this.canDownload() && this.enableLegalText && !this.textLegal;
  }
}
