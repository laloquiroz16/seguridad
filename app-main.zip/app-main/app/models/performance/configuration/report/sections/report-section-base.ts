import { Expose, Type } from "class-transformer";
import { ReportSection } from "@models/performance/configuration";

export class ReportSectionBase {
  id?: number;

  @Expose({ name: "section_attributes" })
  @Type(() => ReportSection)
  section: ReportSection;
}
