import { Expose, Type } from "class-transformer";

import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { ReportDomain } from "@models/performance/configuration";

export class ReportSectionCompetencesComparative extends ReportSectionBase {
  @Expose({ name: "domains_attributes" })
  @Type(() => ReportDomain)
  domains: ReportDomain[];

  @Expose({ name: "show_conducts" })
  showConducts: boolean;

  @Expose({ name: "show_comments" })
  showComments: boolean;

  @Expose({ name: "show_joint_review_comments" })
  showJointReviewComments: boolean;

  @Expose({ name: "expand_table" })
  expandTable: boolean;
}
