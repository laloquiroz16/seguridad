import { Expose, Type } from "class-transformer";

import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { ReportDomain } from "@models/performance/configuration";

export class ReportSectionAverage extends ReportSectionBase {
  @Expose({ name: "domains_attributes" })
  @Type(() => ReportDomain)
  domains: ReportDomain[];
}
