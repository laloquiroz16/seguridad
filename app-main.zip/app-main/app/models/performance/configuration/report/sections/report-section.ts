import { Expose } from "class-transformer";

export class ReportSection {
  id?: number;

  @Expose({ name: "show_section" })
  showSection: boolean = false;
}
