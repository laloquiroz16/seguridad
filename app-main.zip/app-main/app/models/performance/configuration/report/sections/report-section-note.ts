import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { Expose } from "class-transformer";

export class ReportSectionNote extends ReportSectionBase {
  @Expose({ name: "can_create_notes" })
  canCreateNotes: boolean;

  @Expose({ name: "show_closing_comments" })
  showClosingComments: boolean;

  @Expose({ name: "show_feedback_comment" })
  showFeedbackComment: boolean;

  @Expose({ name: "can_create_private_notes" })
  canCreatePrivateNotes: boolean;

  @Expose({ name: "show_public_notes" })
  showPublicNotes: boolean;

  @Expose({ name: "show_private_notes" })
  showPrivateNotes: boolean;

  @Expose({ name: "show_coordination_survey" })
  showCoordinationSurvey: boolean;

  @Expose({ name: "show_navbar_note" })
  showNavbarNote: boolean;
}
