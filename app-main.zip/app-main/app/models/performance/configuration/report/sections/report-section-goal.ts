import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { Expose } from "class-transformer";
import { GoalType } from "../enum/goal-type";

export class ReportSectionGoal extends ReportSectionBase {
  @Expose({ name: "show_objective" })
  showObjective: boolean;

  @Expose({ name: "show_objective_ponderation" })
  showObjectivePonderation: boolean;

  @Expose({ name: "show_ponderation" })
  showPonderation: boolean;

  @Expose({ name: "show_accomplishment" })
  showAccomplishment: boolean;

  @Expose({ name: "show_expected_value" })
  showExpectedValue: boolean;

  @Expose({ name: "show_score" })
  showScore: boolean;

  @Expose({ name: "show_grade" })
  showGrade: boolean;

  @Expose({ name: "show_comment" })
  showComment: boolean;

  @Expose({ name: "show_due_date" })
  showDueDate: boolean;

  @Expose({ name: "type_goal" })
  goalType: GoalType;

  status() {
    return (
      this.showAccomplishment ||
      this.showComment ||
      this.showObjective ||
      this.showPonderation ||
      this.showExpectedValue ||
      this.showGrade ||
      this.showComment ||
      this.showDueDate
    );
  }
  updateAllField() {
    const newStatus = !this.status();
    this.showObjective = newStatus;
    this.showPonderation = newStatus;
    this.showAccomplishment = newStatus;
    this.showExpectedValue = newStatus;
    this.showScore = newStatus;
    this.showGrade = newStatus;
    this.showComment = newStatus;
    this.showDueDate = newStatus;
  }
  updateFeedbackField() {
    const newStatus = !this.status();
    this.showObjective = newStatus;
    this.showPonderation = newStatus;
    this.showDueDate = newStatus;
  }

  isGeneral() {
    return this.goalType === GoalType.General;
  }
}
