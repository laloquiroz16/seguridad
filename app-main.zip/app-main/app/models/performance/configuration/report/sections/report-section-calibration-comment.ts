import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { Expose } from "class-transformer";

export class ReportSectionCalibrationComment extends ReportSectionBase {
  @Expose({ name: "show_comment" })
  showComment: boolean = false;
  @Expose({ name: "show_comment_type" })
  showCommentType: boolean = false;
  @Expose({ name: "show_critical_talent" })
  showCriticalTalent: boolean = false;
  @Expose({ name: "show_calibration_label" })
  showCalibrationLabel: boolean = false;
  @Expose({ name: "show_impact_and_risk_of_leakage" })
  showImpactAndRiskOfLeakage: boolean = false;
}
