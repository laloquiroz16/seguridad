import { Expose, Type } from "class-transformer";

import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { ReportCollaborator } from "@models/performance/configuration";

export class ReportSectionPersonalInformation extends ReportSectionBase {
  @Expose({ name: "collaborators_attributes" })
  @Type(() => ReportCollaborator)
  collaborators: ReportCollaborator[];
}
