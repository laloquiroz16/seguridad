import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";

export class ReportSectionClosingSurvey extends ReportSectionBase {}
