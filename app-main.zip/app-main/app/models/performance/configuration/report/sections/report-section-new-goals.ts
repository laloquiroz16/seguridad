import { Expose, Type } from "class-transformer";

import { ReportAverageAttribute } from "@models/performance/configuration";
import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";

export class ReportSectionNewGoals extends ReportSectionBase {
  @Expose({ name: "average_attribute_new_goals_attributes" })
  @Type(() => ReportAverageAttribute)
  averageAttributes: ReportAverageAttribute[] = [];
}
