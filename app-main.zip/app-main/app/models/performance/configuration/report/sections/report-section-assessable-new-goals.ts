import { Expose } from "class-transformer";
import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";

export class ReportSectionAssessableNewGoals extends ReportSectionBase {
  @Expose({ name: "show_descending" })
  showDescending: boolean = false;
  @Expose({ name: "show_self_assessment" })
  showSelfAssessment: boolean = false;
}
