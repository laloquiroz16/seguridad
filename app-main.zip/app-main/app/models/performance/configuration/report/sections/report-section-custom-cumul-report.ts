import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { Expose } from "class-transformer";

export class ReportSectionCustomCumulReport extends ReportSectionBase {
  @Expose({ name: "dashboard_token" })
  dashboardToken: string;
}
