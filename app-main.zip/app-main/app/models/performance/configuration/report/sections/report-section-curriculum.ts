import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";

export class ReportSectionCurriculum extends ReportSectionBase {
  answers_attributes: any;
}
