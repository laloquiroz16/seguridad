import { Expose, Type } from "class-transformer";

import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import {
  ConductTableType,
  ReportDomain
} from "@models/performance/configuration";

export class ReportSectionCompetence extends ReportSectionBase {
  @Expose({ name: "domains_attributes" })
  @Type(() => ReportDomain)
  domains: ReportDomain[];

  @Expose({ name: "type_conduct_table" })
  conductTableType: ConductTableType;
}
