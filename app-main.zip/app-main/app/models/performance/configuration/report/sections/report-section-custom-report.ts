import { Expose } from "class-transformer";

import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";

export class ReportSectionCustomReport extends ReportSectionBase {
  @Expose({ name: "report_token" })
  reportToken: string;
}
