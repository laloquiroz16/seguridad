import { ReportSectionBase } from "@models/performance/configuration/report/sections/report-section-base";
import { Expose, Type } from "class-transformer";
import { ReportDomain } from "@models/performance/configuration";

export class ReportSectionGraphicSpider extends ReportSectionBase {
  @Expose({ name: "domains_attributes" })
  @Type(() => ReportDomain)
  domains: ReportDomain[];
  @Expose({ name: "show_value" })
  showValue: boolean;
  @Expose({ name: "show_label" })
  showLabel: boolean;
}
