import { Expose, Exclude } from "class-transformer";
import { AssessmentAccess } from "@enums/performance/assessment-access.enum";
import { FeedbackAccess } from "@enums/performance/feedback-access.enum";

export class ConfigurationCalibration {
  @Exclude({ toPlainOnly: true })
  id?: number;
  @Expose({ name: "is_bulk_calibration" })
  isBulkCalibration: boolean;
  @Expose({ name: "enable_comment_type" })
  enableCommentType: boolean;
  @Expose({ name: "meetings_enabled" })
  meetingsEnabled: boolean;
  @Expose({ name: "enable_critical_talent" })
  enableCriticalTalent: boolean;
  @Expose({ name: "enable_note" })
  enableNote: boolean;
  @Expose({ name: "enabled_new_commitment_calibration" })
  enabledNewCommitmentCalibration: boolean;
  @Expose({ name: "feedback_access" })
  feedbackAccess: FeedbackAccess;
  @Expose({ name: "assessment_access" })
  assessmentAccess: AssessmentAccess;
  @Expose({ name: "calibrate_evaluation_domain" })
  calibrateEvaluationDomain: boolean;
  @Expose({ name: "show_distribution_table" })
  showDistributionTable: boolean;
  @Expose({ name: "enable_percentage_curve" })
  enablePercentageCurve: boolean;
  @Expose({ name: "matrix_position_based_on_general_result" })
  matrixPositionBasedOnGeneralResult: boolean;
  @Expose({ name: "enable_impact_and_risk_of_leakage" })
  enableImpactAndRiskOfLeakage: boolean;
  @Expose({ name: "matrix_display_type" })
  matrixDisplayType: string;
}
