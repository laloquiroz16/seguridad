import { Exclude, Expose } from "class-transformer";

export class FeedbackConfiguration {
  @Exclude({ toPlainOnly: true })
  id?: number;
  @Expose({ name: "allow_new_score" })
  allowNewScore: boolean;
  @Expose({ name: "create_comment" })
  createComment: boolean;
  @Expose({ name: "required_comment" })
  requiredComment: boolean;
  @Expose({ name: "min_char_comment" })
  minCharComment: number;
  @Expose({ name: "enable_notify_boss" })
  enableNotifyBoss: boolean;
  @Expose({ name: "min_evaluation_for_feedback_access" })
  minEvaluationForFeedbackAccess: boolean;
  @Expose({ name: "enable_evaluator_feedback_letter" })
  enableEvaluatorFeedbackLetter: boolean;
  @Expose({ name: "mandatory_evaluator_feedback_comment" })
  mandatoryEvaluatorFeedbackComment: boolean;
  @Expose({ name: "enable_evaluable_feedback_letter" })
  enableEvaluableFeedbackLetter: boolean;
  @Expose({ name: "feedback_letter_after_closing_survey" })
  feedbackLetterAfterClosingSurvey: boolean;
  @Expose({ name: "show_closing_survey_column" })
  showClosingSurveyColumn: boolean;
  @Expose({ name: "show_feedback_type_column" })
  showFeedbackTypeColumn: boolean;
  @Expose({ name: "restrict_access_to_self_results" })
  restrictAccessToSelfResults: boolean;
  @Expose({ name: "able_access_during_evaluation" })
  ableAccessDuringEvaluation: boolean;
  @Expose({ name: "notes_required_to_finish_feedback" })
  notesRequiredToFinishFeedback: boolean;
  @Expose({ name: "min_evaluator_notes_required" })
  minEvaluatorNotesRequired: number;
  @Expose({ name: "min_evaluable_notes_required" })
  minEvaluableNotesRequired: number;
  @Expose({ name: "restrict_results_for_evaluators_and_evaluables" })
  restrict_results_for_evaluators_and_evaluables: boolean;
  @Expose({ name: "enable_extended_feedback_letter" })
  enable_extended_feedback_letter: boolean;
  @Expose({ name: "enable_feedback_questions_by_evaluable" })
  enable_feedback_questions_by_evaluable: boolean;
  @Expose({ name: "enable_feedback_message_mode_given" })
  enable_feedback_message_mode_given: boolean;
}
