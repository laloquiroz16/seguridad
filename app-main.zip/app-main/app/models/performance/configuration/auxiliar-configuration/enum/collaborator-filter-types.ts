export enum CollaboratorFilterTypes {
  Enterprise = "enterprise",
  EnterpriseProcess = "enterprise_process",
  Subdomain = "subdomain"
}
