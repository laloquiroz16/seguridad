import { Expose } from "class-transformer";
import { CollaboratorFilterTypes } from "./enum/collaborator-filter-types";

export class AuxiliarConfiguration {
  id: any;

  @Expose({ name: "onepage" })
  onepage: boolean;

  @Expose({ name: "default_replay_goal" })
  replayGoal: boolean;

  @Expose({ name: "use_new_survey_maker" })
  useNewSurveyMaker: boolean;

  @Expose({ name: "collaborator_filter_type" })
  collaboratorFilterType: CollaboratorFilterTypes;

  @Expose({ name: "collaborators_in_default_no_area" })
  collaboratorsInDefaultNoArea: boolean;

  @Expose({ name: "active_new_goal" })
  activeNewGoal: boolean;

  fixation: boolean;

  assessment: boolean;

  @Expose({ name: "active_automatic_ponderations" })
  activeAutomaticPonderations: boolean;

  @Expose({ name: "manager_access_self_results" })
  managerAccessSelfResults: boolean;

  @Expose({ name: "manager_access_evaluator_results" })
  managerAccessEvaluatorResults: boolean;

  @Expose({ name: "required_pages" })
  requiredPages: IRequiredSurveyPage[];

  @Expose({ name: "require_self_assessment_for_descending_category" })
  requireSelfAssessmentForDescendingCategory: boolean;

  @Expose({ name: "show_evaluation_global_summary" })
  showEvaluationGlobalSummary: boolean;

  @Expose({ name: "feedback_letter_enabled" })
  feedbackLetterEnabled: boolean;

  @Expose({ name: "activate_appeal" })
  activateAppeal: boolean;
}

export interface IRequiredSurveyPage {
  id: number;
  title_translate: string;
  tag: string;

  // Sólo para el front
  checked?: boolean;
}
