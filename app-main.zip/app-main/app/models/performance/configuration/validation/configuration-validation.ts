import { Expose } from "class-transformer";

export class ConfigurationValidation {
  id: number;

  @Expose({ name: "send_evaluation_to_validation_mail" })
  sendEvaluationToValidationMail: boolean;
}
