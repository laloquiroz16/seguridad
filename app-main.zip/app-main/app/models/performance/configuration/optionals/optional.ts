import { Expose } from "class-transformer";

export class Optional {
  id?: number;
  name: string = "";
  @Expose({ name: "name_translate" })
  nameTranslate: boolean;
}
