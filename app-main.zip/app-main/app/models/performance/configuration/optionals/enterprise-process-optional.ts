import { Expose, Exclude, Type } from "class-transformer";
import { Optional } from "./optional";

export class EnterpriseProcessOptional {
  @Exclude({ toPlainOnly: true })
  id?: number;
  order: number;
  include: boolean;

  @Expose({ name: "optional_id" })
  optionalId: boolean;

  @Expose({ name: "optional" })
  @Type(() => Optional)
  optional: Optional;
}
