import { Exclude, Expose, Type } from "class-transformer";
import { MultipleAssessment } from "./multiple-assessment";
import { AssessmentGoal } from "./assessment-goal";

export class AssessmentConfiguration {
  @Exclude({ toPlainOnly: true })
  id?: number;
  @Expose({ name: "multiple_assessment_attributes" })
  @Type(() => MultipleAssessment)
  multipleAssessment: MultipleAssessment;
  @Expose({ name: "assessment_goal_attributes" })
  @Type(() => AssessmentGoal)
  assessmentGoal: AssessmentGoal;
  show_report_in_evaluation: boolean;
  show_report_in_evaluation_categories_ids: { categories_ids: number[] };
  show_report_in_evaluation_process_id: number;
  related_feedback_private: boolean;
  enable_general_average: boolean;
  enable_new_evaluables_list: boolean;
  show_external_results_link: boolean;
  show_autoevaluation_column: boolean;
  show_general_associated_feedback: boolean;
  @Expose({ name: "form_competence_domain_id" })
  formCompetenceDomainId: number;
}
