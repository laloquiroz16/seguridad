import { Expose } from "class-transformer";

export class AssessmentGoal {
  @Expose({ name: "hide_goal_button" })
  hideGoalButton: boolean;

  @Expose({ name: "hide_goals_weighted_compliance" })
  hideGoalsWeightedCompliance: boolean;

  @Expose({ name: "hide_objective_ponderation" })
  hideObjectivePonderation: boolean;

  @Expose({ name: "show_goals_description" })
  showGoalsDescription: boolean;
}
