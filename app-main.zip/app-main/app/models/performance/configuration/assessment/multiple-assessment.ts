import { Expose } from "class-transformer";

export class MultipleAssessment {
  @Expose({ name: "is_enabled" })
  isEnabled: boolean;
}
