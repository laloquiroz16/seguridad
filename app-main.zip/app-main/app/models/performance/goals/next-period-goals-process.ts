import { Type, Expose } from "class-transformer";
import { NextPeriodGoalsConfiguration } from "@models/performance/configuration/next-period-goals/next-period-goals-configuration";

export class NextPeriodGoalsProcess {
  id: number;
  status: number;
  @Expose({ name: "results_precision" })
  resultsPrecision: number;

  @Expose({ name: "role_in_process" })
  roleInProcess: any;

  @Expose({ name: "is_evaluator" })
  isEvaluator: boolean;

  @Type(() => NextPeriodGoalsConfiguration)
  @Expose({ name: "next_period_goals_configuration" })
  nextPeriodGoalsConfiguration: NextPeriodGoalsConfiguration;
}
