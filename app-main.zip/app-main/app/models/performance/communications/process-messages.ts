export enum ProcessMessages {
  closing_feedback_message = "closingFeedbackMessage"
}
