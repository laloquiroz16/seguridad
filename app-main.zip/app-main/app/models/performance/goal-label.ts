export interface IGoalLabel {
  /**
   * @description The order on the dropdown, and also the score that will be assigned
   */
  order: number;
  /**
   * @description The description to be used on the dropdown
   */
  label: string;
}
