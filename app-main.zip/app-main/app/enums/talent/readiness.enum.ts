enum ReadinessEnum {
  RZero = 0,
  ROne = 1,
  RTwo = 2
}

export { ReadinessEnum };
