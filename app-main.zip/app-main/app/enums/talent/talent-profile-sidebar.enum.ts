enum TalentProfileSidebar {
  profile = "Datos del usuario",
  calibration = "Cambiar posición",
  notes = "Notas",
  actionPlans = "Planes de acción",
  sucessionSurvey = "Encuesta de sucesión",
  history = "Historial de cambios",
  curriculum = "Curriculum",
  successionTree = "Árbol de sucesión"
}

export { TalentProfileSidebar };
