enum MatrixAxis {
  XAxis = "x",
  YAxis = "y"
}

export { MatrixAxis };
