enum TalentAmplitudeEvents {
  MatrixGeneral = "Talento: Matrix initialized",
  MatrixViewType = "Talento: Matrix Tab Clicked",
  ProfileSectionClick = "Talento: Profile Section Click",
  IndividualReportDownloaded = "Talento: Individual Report Downloaded",
  RevisionFinished = "Talento: Revision Finished",
  GeneralReportDownloaded = "Talento: General Report Downloaded",
  ChangingPositionEvaluable = "Talento: Changing Position Evaluable",
  TalentPeriodConfiguration = "Talento: Talent Period Configuration",
  TalentEditPeriod = "Talento: Talent Edit Period",
  TalentPeriodResults = "Talento: Talent Edit Period Results",
  UploadCollaboratorsToProcess = "Talento: Upload collaborators to process",
  TalentMainConfiguration = "Talento: Main Configuration",
  TalentUpdateConfiguration = "Talento: Update Configuration",
  TalentLayersConfiguration = "Talento: Layers Configuration",
  TalentLayersConfigurationSave = "Talento: Layers Configuration Save",
  TalentReviewClicked = "Talento: Talent Revision Clicked",
  UpdateCollaboratorPosition = "Talento: Update Collaborator Position"
}

export { TalentAmplitudeEvents };
