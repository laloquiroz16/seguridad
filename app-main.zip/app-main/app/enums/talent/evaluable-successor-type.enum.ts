enum EvaluableSuccessorType {
  Ascending = 1,
  Promotion = 2
}

export { EvaluableSuccessorType };
