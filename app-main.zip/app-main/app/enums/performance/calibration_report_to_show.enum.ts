enum CalibrationReportToShow {
  Link = 0,
  Full = 1,
  Both = 2
}

export { CalibrationReportToShow };
