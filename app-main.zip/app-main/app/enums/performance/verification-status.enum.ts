enum VerificationStatus {
  NotVerificated = 0,
  Pending = 1,
  Verificated = 2
}

export { VerificationStatus };
