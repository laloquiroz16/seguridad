enum PerformanceTabType {
  Feedback = "feedback",
  Coordination = "coordination",
  Evaluations = "evaluations"
}

export default PerformanceTabType;
