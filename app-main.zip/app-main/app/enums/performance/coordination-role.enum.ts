enum CoordinationRole {
  Coordinator = "coordinator"
}

export default CoordinationRole;
