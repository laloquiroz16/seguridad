enum FeedbackAccess {
  Group = 0,
  Individual = 1,
  SkipCalibration = 2
}

export { FeedbackAccess };
