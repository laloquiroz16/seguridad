export enum ResultsIndividualsMenuItemsMain {
  Summary = "feedback-summary-main",
  CompetencesComparative = "feedback-competences-comparative-main",
  Competences = "feedback-competences-main",
  QualitativeQuestion = "feedback-qualitative-questions-main",
  Goals = "feedback-goals-main",
  NewGoals = "feedback-new-goals-main",
  NextPeriodGoals = "feedback-next-period-main",
  GoalsFeedback = "feedback-next-period-old-main",
  ActionPlans = "feedback-action-plans-main",
  Notes = "feedback-notes-main",
  Biography = "feedback-biography-main",
  Form = "feedback-form-main",
  SelfFixation = "feedback-autofixation-goals-main",
  Resume = "feedback-curriculum-main",
  Instructions = "feedback-instructions-main",
  CustomReport = "feedback-custom-report-main",
  CustomCumulReport = "feedback-custom-cumul-report-main"
}
