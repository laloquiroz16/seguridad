export enum PerformanceTypePage {
  Individual = "individual",
  Feedback = "feedback",
  Calibration = "calibration",
  Coordination = "coordination",
  NewEvaluablesList = "newEvaluablesList",
  Final = "final",
  Home = "home"
}
