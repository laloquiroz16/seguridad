enum ProfileAdditionalButtons {
  IndividualReportResults = "individual_report_results"
}

export { ProfileAdditionalButtons };
