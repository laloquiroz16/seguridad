enum FeedbackRedirectEnum {
  Company = "company",
  Individual = "individual",
  PlansList = "plans_list",
  Personal = "personal",
  Feedback = "feedback",
  NewEvaluablesList = "newEvaluablesList",
  EvaluationSummary = "evaluationSummary",
  Validation = "validation",
  ValidationMatricial = "validationMatricial",
  Talent = "Talent",
  Calibration = "calibration",
  Coordination = "coordination",
  Home = "home",
  Setting = "setting",
  ValidationList = "validationList"
}

export { FeedbackRedirectEnum };
