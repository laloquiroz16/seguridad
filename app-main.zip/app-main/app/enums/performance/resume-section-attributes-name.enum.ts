export enum ResumeSectionAttributesName {
  ValidatedByCalibrator = "validated_by_calibrator"
}
