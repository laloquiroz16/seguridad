enum FeedbackClosingSurveyStates {
  Unstarted = 0,
  Finished = 2
}

export { FeedbackClosingSurveyStates };
