enum FormEvaluationType {
  FormText = "form_text",
  FormTextCompetences = "form_text_competences",
  FormInput = "form_input",
  FormSelectSimple = "form_select_simple",
  FormLikert = "form_likert",
  FormDropdown = "form_dropdown",
  FormSelectMultiple = "form_select_multiple"
}

export { FormEvaluationType };
