export enum ResultsIndividualsMenuItems {
  Summary = "summaryId",
  CompetencesComparative = "competencesComparativeId",
  Competences = "competencesId",
  QualitativeQuestion = "qualitativeQuestionId",
  Goals = "goalsId",
  GoalsFeedback = "goalsFeedbackId",
  NewGoals = "assessableNewGoal",
  NextPeriodGoals = "nextPeriodGoalsId",
  ActionPlans = "actionPlansId",
  Notes = "notesId",
  Biography = "biographyId",
  Form = "formId",
  SelfFixation = "selfFixationId",
  Resume = "resumeId",
  Instructions = "instructionsId",
  CustomReport = "customReportId",
  CustomCumulReport = "customCumulReportId"
}
