export enum ParticipantsTabs {
  active = "active",
  inactive = "inactive"
}
