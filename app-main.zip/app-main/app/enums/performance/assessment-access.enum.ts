enum AssessmentAccess {
  EvaluationCompleted = 0,
  CollaboratorCalibrated = 1,
  GroupCalibratedAndEvaluationCompleted = 2
}

export { AssessmentAccess };
