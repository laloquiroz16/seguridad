enum ContinuousGoalNotification {
  Evaluator = "notify_evaluator",
  Collaborator = "notify_collaborator"
}

export { ContinuousGoalNotification };
