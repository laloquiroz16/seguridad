export enum SurveyPageIdentifier {
  GoalsAndObjectives = "goalsAndObjectives",
  Competences = "competences",
  Resume = "resume",
  Form = "form"
}
