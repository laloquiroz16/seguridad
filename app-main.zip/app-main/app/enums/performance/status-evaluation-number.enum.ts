export enum StatusEvaluationNumber {
  ToStart = 0,
  InDraft = 1,
  SignedByCollab = 2,
  FinishedByEvaluator = 3,
  ModifiedByEvaluator = 4,
  EvaluationInProcess = 5,
  EvaluationFinished = 6
}
