enum FeedbackStatus {
  FinalizedFeedback = "finalized_feedback"
}

export { FeedbackStatus };
