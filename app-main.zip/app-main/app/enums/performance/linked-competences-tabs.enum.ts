export enum LinkedCompetencesTabs {
  Answers = "answers",
  Frequency = "frequency"
}
