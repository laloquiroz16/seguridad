enum UserResumeStatus {
  NotStarted = "not_started",
  NotStated = "not_stated", // typo in back
  Started = "started",
  Completed = "completed"
}

export { UserResumeStatus };
