enum ProfileTabEnum {
  Evaluations = "evaluations",
  Objective = "objectives",
  Data = "dataUser",
  Competences = "competences",
  ChangeHistory = "changeHistory"
}

export { ProfileTabEnum };
