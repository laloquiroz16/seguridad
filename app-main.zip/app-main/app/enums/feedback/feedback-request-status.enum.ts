export enum FeedbackRequestStatus {
  PENDING = 1,
  GIVED = 2
}
