export enum RecentFeedbackShow {
  ScoreAndCompetences = 1,
  CommentAndCompetences = 2,
  CommentScoreAndCompetences = 3
}
