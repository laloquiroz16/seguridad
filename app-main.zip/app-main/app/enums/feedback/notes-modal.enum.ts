export enum NotesModal {
  PrivateNote = "private",
  PublicNote = "public"
}
