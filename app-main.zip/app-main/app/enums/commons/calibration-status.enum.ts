export enum CalibrationStatus {
  /**
   * @description To be verified. Empty status must also be treated as unstarted status
   */
  NotCalibrated = 0,
  /**
   * @description Verification started but uncompleted
   */
  Pending = 1,
  /**
   * @description Verification completed
   */
  Calibrated = 2
}
