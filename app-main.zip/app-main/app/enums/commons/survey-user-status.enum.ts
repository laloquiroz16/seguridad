export enum SurveyUserStatus {
  ForInviting = 0,
  Invited = 1
}
