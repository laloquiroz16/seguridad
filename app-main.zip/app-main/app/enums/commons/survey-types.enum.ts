export enum SurveyTypes {
  Engagement = 1,
  Gptw = 2,
  OpenSurvey = 3,
  PulseSurvey = 4
}
