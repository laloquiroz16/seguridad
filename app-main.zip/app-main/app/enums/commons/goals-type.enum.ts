export enum GoalsType {
  inpNum = "inp_num",
  prcSimpl = "prc_simpl",
  range = "range",
  numericRange = "numeric_range",
  ancCond = "anc_cond",
  achievement = "achievement",
  likertDescription = "likert_description",
  ancCondCompetence = "anc_cond_competence",
  prcSimplKpi = "prc_simpl_kpi",
  kpi = "kpi",
  likert = "likert",
  percentage = "percentage",
  numeric = "numeric",
  linearInterpolation = "linear_interpolation"
}
