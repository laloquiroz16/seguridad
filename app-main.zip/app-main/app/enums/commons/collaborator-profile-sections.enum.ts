export enum CollaboratorProfileSections {
  MyProcess = "myProcess",
  Summary = "summary"
}
