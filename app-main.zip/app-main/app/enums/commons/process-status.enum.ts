export enum ProcessStatus {
  /**
   * @description Used in CSI, Performance
   */
  Disabled = 0,
  /**
   * @description Used in CSI, Performance. Backend name: evaluation
   */
  Assessment = 1,
  /**
   * @description Used in Performance
   */
  Feedback = 2,
  /**
   * @description Used in Performance
   */
  ResultAccessing = 3,
  /**
   * @description Used in Performance. Backend name: ObjectivesFijation
   */
  ObjectivesSetting = 4,
  /**
   * @description Used in CSI, Performance
   */
  Verification = 5,
  /**
   * @description Used in Performance
   */
  Inactive = 6,
  /**
   * @description Used in Performance
   */
  Calibration = 7
}
