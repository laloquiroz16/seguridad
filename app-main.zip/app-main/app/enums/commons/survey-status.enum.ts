export enum SurveyStatus {
  Unstarted = 0,
  InProcess = 1,
  Finished = 2
}
