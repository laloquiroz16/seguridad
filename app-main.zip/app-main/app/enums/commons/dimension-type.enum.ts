export enum DimensionType {
    Evaluation = "evaluation",
    EvaluationCompetences = "evaluation_competences",
    CategoryCompetence = "category_competence",
    EvaluationGoals = "evaluation_goals",
    EvaluationDomain = "evaluation_domain"
  }
  

