export enum Succession {
  evaluable = 1,
  evaluator = 2,
  global = 3
}
