export enum SettingObjective {
  /**
   * @description the collaborator has no charged goals
   */
  ForEntering = 0,

  /**
   * @description the collaborator has goals charged
   * (entered by the evaluator or the same),
   * but not yet finished
   */
  InDraft = 1,

  /**
   * @description the collaborator has finished signing his goals
   */
  SignedByCollaborator = 2,

  /**
   * @description the evaluator has finalized the process objectives settings
   */
  SignedByEvaluator = 3,

  /**
   * @description the evaluator modified the objectives signed
   */
  ModifyByEvaluator = 4,
  /**
   * @description the user not is include in process
   */
  NotIncluded = 5,

  /**
   * @description Indicates than the objectives setting is allowed assessment
   */
  AssessmentInProgress = 6,

  /**
   * @description Indicates that process assessment is finalized
   */
  AssessmentFinished = 7
}
