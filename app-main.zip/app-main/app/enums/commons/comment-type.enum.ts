export enum CommentType {
  Promotion = 1,
  WithHold = 2,
  Unlink = 3
}
