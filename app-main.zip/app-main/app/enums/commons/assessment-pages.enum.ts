export enum AssessmentPages {
  Competences = "competences",
  QualitativeQuestions = "qualitativeQuestions",
  GoalsAndObjectives = "goalsAndObjectives",
  AutofixationGoals = "autofixationGoals",
  Form = "form",
  ContinuousGoals = "continuousGoals",
  Resume = "resume",
  NextPeriodGoals = "nextPeriodGoals",
  NewGoals = "newGoals",
  CommitmentsEvaluation = "commitmentsEvaluation"
}
