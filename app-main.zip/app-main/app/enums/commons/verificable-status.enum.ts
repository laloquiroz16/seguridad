export enum VerificableStatus {
  /**
   * @description To be verified. Empty status must also be treated as unstarted status
   */
  Unstarted = 0,
  /**
   * @description Verification started but uncompleted
   */
  Started = 1,
  /**
   * @description Verification completed
   */
  Completed = 2
}
