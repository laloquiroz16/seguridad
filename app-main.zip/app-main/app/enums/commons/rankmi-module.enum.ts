export enum RankmiModule {
  Performance = 1,
  Gptw = 2,
  Engagement = 3,
  Talent = 4,
  Feedback = 5,
  Satisfaction = 6,
  Lms = 7
}
