export enum CalibrationRole {
  Calibrated = "calibrated",
  Calibrator = "calibrator"
}
