export enum ProcessPage {
  Assessment = "Assessment",
  Feedback = "Feedback"
}
