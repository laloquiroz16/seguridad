export enum VerificationStatus {
  NotVerified = 0,
  Verified = 1
}
