export enum Dimension {
    Domain = "domain",
    Competences = "competences",
    CategoryCompetence = "category_competence",
    Goals = "goals",
    AverageDomain = "average_domain"
}