export enum OpenSurveyStatus {
  Finished = "finished",
  InProcess = "in_process"
}
