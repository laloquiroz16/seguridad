export enum RankmiPusheableSelect {
  NotExist = -1
}
