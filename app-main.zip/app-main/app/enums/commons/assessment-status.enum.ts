export enum AssessmentStatus {
  Unstarted = 0,
  Draft = 1,
  SigningCollaborator = 2,
  SigningEvaluator = 3,
  ModifyEvaluator = 4
}
