export enum EvaluationStatus {
  Initial = 0,
  InProgress = 1,
  Finalized = 2,
  ValidationPending = 3,
  ValidationRejected = 4,
  ValidationAccepted = 5
}
