export enum OptionalTypes {
  List = "list",
  Checkbox = "checkbox",
  Text = "text",
  Date = "date",
  Radio = "radio",
  Number = "number",
  Boolean = "boolean"
}
