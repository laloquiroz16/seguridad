export enum AreasHierachyActions {
  Reporting = "open_survey_result",
  Monitoring = "open_survey_monitoring",
  Configuration = "open_survey_config"
}
