export enum ParticipantTypeEnum {
  Collaborators = 0,
  Segments = 1,
  AllCollaborators = 2
}
