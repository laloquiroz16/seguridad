enum Source {
  Performance = "performance",
  GPTW = "gptw",
  Engagement = "engagement",
  Talent = "talent",
  Satisfaction = "satisfaction",
  LMS = "lms",
  OrganizationChart = "organization_chart",
  NewFeedback = "new_feedback",
  Home = "home",
  Reports = "reports"
}

export { Source };
