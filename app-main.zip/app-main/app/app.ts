import "core-js/stable";
import "regenerator-runtime/runtime";
import angular from "angular";
import "angular-cookies";
import "angular-moment";
import "angular-cookie";
import "ng-progress-arc";
import "angular-dynamic-locale";
import "angular-translate";
import "reflect-metadata";
import "antd/dist/antd.css";
import "@rankmi/rankmi-styles/dist/css/reset-ant/main.css";

import { RoutingConfiguration } from "./configs/routes";
import { ToastyModule } from "./libs/toasty-custom";
import {
  LogoutController,
  SSOComponent,
  SSOLoginService,
  SSOCustomComponent,
  SSOKeycloakComponent,
  SSOGenericComponent
} from "./modules/auth";
import { AccountService } from "./services/account.service";
import { SessionService } from "./services/session.service";
import {
  PasswordVerifyDirective,
  UserModelService
} from "./services/userModel";

import { AppBootstrapRunFn } from "./app-bootstrap.run";
import "./assets/less/app.less";
import "./assets/scss/app.scss";
import { NgTranslateConfiguration } from "./configs/angular-translate.config";
import NgCompileConfiguration from "./configs/compile-provider.config";
import {
  AuthenticationAndLogConfiguration,
  HttpConfiguration,
  ToastyConfiguration
} from "./configs/configs";
import { BaseModule } from "@base/base.module";
import { react2angular } from "react2angular";

import LoginPage from "@src/auth/src/pages/login";
import Freshdesk from "@src/auth/src/pages/freshdesk";
import UpdatePasswordPage from "@src/auth/src/pages/update-password";
import MobileAsideWrapper from "@src/mobile/mobile-aside/MobileAsideWrapper";
import MobileSidebarWrapper from "@src/mobile/mobile-sidebar/MobileSidebarWrapper";
import MobileGroupsSidebarWrapper from "@src/mobile/mobile-groups-sidebar/MobileGroupsSidebarWrapper";
import { GoogleAnalyticsController } from "./modules/googleAnalytics/googleAnalytics.controller";

import { RankmiUserIdleTracker } from "@src/auth/src/components/templates/user-idle-tracker/wrapper";

export const AppModule = angular
  .module("rankmiApp", [
    ToastyModule.name,
    "ngCookies",
    "angularMoment",
    "pascalprecht.translate",
    "tmh.dynamicLocale",
    "ng-progress-arc",
    BaseModule.name
  ])
  .controller("logoutController", LogoutController)
  .component("updatePasswordComponent", react2angular(UpdatePasswordPage))
  .service("userModel", UserModelService)
  .directive("passwordVerify", PasswordVerifyDirective)
  .service("accountService", AccountService)
  .service("sessionService", SessionService)
  .config(RoutingConfiguration)
  .config(AuthenticationAndLogConfiguration)
  .config(HttpConfiguration)
  .config(ToastyConfiguration)
  .config(NgCompileConfiguration)
  .component("loginTemplate", react2angular(LoginPage))
  .component("ssoComponent", SSOComponent)
  .component("freshdesk", react2angular(Freshdesk))
  .component("ssoCustomComponent", SSOCustomComponent)
  .component("ssoKeycloakComponent", SSOKeycloakComponent)
  .component("ssoGenericComponent", SSOGenericComponent)
  .component("mobileAside", react2angular(MobileAsideWrapper))
  .component("mobile", react2angular(MobileSidebarWrapper))
  .component("mobileGroupsSidebar", react2angular(MobileGroupsSidebarWrapper))
  .component(
    "rankmiUserIdleTracker",
    react2angular(RankmiUserIdleTracker, null, ["sessionService"])
  )
  .service("ssoLoginService", SSOLoginService)
  .run(AppBootstrapRunFn)
  .run(GoogleAnalyticsController)
  .config(NgTranslateConfiguration).name;
